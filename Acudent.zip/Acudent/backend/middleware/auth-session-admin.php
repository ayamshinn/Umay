            <?php
            // auth-check.php (TEST ONLY – insecure)

            session_start();
            if (empty($_SESSION['user_id'])) {
                // Fallback: Check token if session is missing
                require_once $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/api/auth/validate-token/validate-token.php';
                if (!validateToken()) {
                    header('Location: ../../views/user-interface/index.php');
                    exit;
                }
            }
            // Allow page to continue
            // If here, user is logged in — allow page to continue
            ?>
