<?php
header("Content-Type: application/json");
session_start();

/* ===================== DB CONNECTION ===================== */
$dbPath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';
if (!file_exists($dbPath)) {
    echo json_encode(["success" => false, "message" => "Server error: DB connection missing."]);
    exit;
}
require_once $dbPath;

/* ===================== REQUEST CHECK ===================== */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

/* ===================== INPUT ===================== */
$input = json_decode(file_get_contents('php://input'), true);

$firstName = trim($input['first_name'] ?? '');
$lastName = trim($input['last_name'] ?? '');
$email = strtolower(trim($input['email'] ?? ''));
$password = trim($input['password'] ?? '');
$confirmPassword = trim($input['confirm_password'] ?? '');

/* ===================== VALIDATION ===================== */
$errors = [];

// Required fields
if (empty($firstName)) $errors[] = "First name is required";
if (empty($lastName)) $errors[] = "Last name is required";
if (empty($email)) $errors[] = "Email is required";
if (empty($password)) $errors[] = "Password is required";
if (empty($confirmPassword)) $errors[] = "Password confirmation is required";

// Email validation
if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Invalid email format";
}

// Password validation
if (!empty($password)) {
    if (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters";
    }
    if (!preg_match('/\d/', $password)) {
        $errors[] = "Password must contain at least one number";
    }
    if (!preg_match('/[^A-Za-z0-9]/', $password)) {
        $errors[] = "Password must contain at least one special character";
    }
}

// Password match
if ($password !== $confirmPassword) {
    $errors[] = "Passwords do not match";
}

// Return validation errors
if (!empty($errors)) {
    echo json_encode([
        'success' => false,
        'message' => 'Validation failed',
        'errors' => $errors
    ]);
    exit;
}

/* ===================== CHECK EXISTING EMAIL ===================== */
$checkEmailQuery = "SELECT user_id FROM Users_tb WHERE email = ? LIMIT 1";
$checkStmt = $conn->prepare($checkEmailQuery);
if (!$checkStmt) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $conn->error
    ]);
    exit;
}

$checkStmt->bind_param("s", $email);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows > 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Email already registered'
    ]);
    exit;
}

/* ===================== GET PATIENT ROLE ID ===================== */
$roleQuery = "SELECT role_id FROM Roles_tb WHERE role_name = 'Patient' LIMIT 1";
$roleResult = $conn->query($roleQuery);

if (!$roleResult) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $conn->error
    ]);
    exit;
}

if ($roleResult->num_rows === 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Patient role not found in system'
    ]);
    exit;
}

$roleData = $roleResult->fetch_assoc();
$patientRoleId = $roleData['role_id'];

/* ===================== GENERATE USER CODE ===================== */
function generateUserCode($conn, $prefix = 'PAT') {
    $maxAttempts = 10;
    for ($i = 0; $i < $maxAttempts; $i++) {
        $randomNumber = str_pad(mt_rand(1, 999999), 6, '0', STR_PAD_LEFT);
        $userCode = $prefix . $randomNumber;
        
        $checkQuery = "SELECT user_id FROM Users_tb WHERE user_code = ? LIMIT 1";
        $checkStmt = $conn->prepare($checkQuery);
        $checkStmt->bind_param("s", $userCode);
        $checkStmt->execute();
        $result = $checkStmt->get_result();
        
        if ($result->num_rows === 0) {
            return $userCode;
        }
    }
    return null;
}

$userCode = generateUserCode($conn, 'PAT');
if (!$userCode) {
    echo json_encode([
        'success' => false,
        'message' => 'Failed to generate unique user code'
    ]);
    exit;
}

/* ===================== HASH PASSWORD ===================== */
$passwordHash = password_hash($password, PASSWORD_DEFAULT);

/* ===================== INSERT USER (WITHOUT PHONE) ===================== */
$insertQuery = "
    INSERT INTO Users_tb (
        user_code,
        role_id,
        first_name,
        last_name,
        email,
        password_hash
    ) VALUES (?, ?, ?, ?, ?, ?)
";

$insertStmt = $conn->prepare($insertQuery);
if (!$insertStmt) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $conn->error
    ]);
    exit;
}

$insertStmt->bind_param(
    "sissss",
    $userCode,
    $patientRoleId,
    $firstName,
    $lastName,
    $email,
    $passwordHash
);

if (!$insertStmt->execute()) {
    echo json_encode([
        'success' => false,
        'message' => 'Failed to create account: ' . $insertStmt->error
    ]);
    exit;
}

$newUserId = $insertStmt->insert_id;

/* ===================== AUTO LOGIN - CREATE SESSION ===================== */
$_SESSION['user'] = [
    'user_id'    => $newUserId,
    'user_code'  => $userCode,
    'email'      => $email,
    'first_name' => $firstName,
    'last_name'  => $lastName,
    'role_id'    => $patientRoleId,
    'role_name'  => 'Patient'
];

/* ===================== GENERATE API TOKEN ===================== */
$token = bin2hex(random_bytes(32));
$expiresAt = date('Y-m-d H:i:s', strtotime('+1 hour'));
$ipAddress = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';

$tokenQuery = "
    INSERT INTO api_tokens (user_id, token, expires_at, ip_address, user_agent)
    VALUES (?, ?, ?, ?, ?)
";
$tokenStmt = $conn->prepare($tokenQuery);
if ($tokenStmt) {
    $tokenStmt->bind_param(
        "issss",
        $newUserId,
        $token,
        $expiresAt,
        $ipAddress,
        $userAgent
    );
    $tokenStmt->execute();
}

/* ===================== SUCCESS RESPONSE ===================== */
echo json_encode([
    'success'  => true,
    'message'  => 'Account created successfully',
    'user'     => [
        'user_id'   => $newUserId,
        'user_code' => $userCode,
        'email'     => $email,
        'first_name' => $firstName,
        'last_name'  => $lastName
    ],
    'token'    => $token,
    'redirect' => '../patient-ui/patient-main.php'
]);
exit;