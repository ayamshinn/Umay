<?php
header("Content-Type: application/json");
session_start();

require_once "../../config/db.php"; // ✅ adjust path to DB

$data = json_decode(file_get_contents("php://input"), true);

$username = trim($data['username'] ?? '');
$password = trim($data['password'] ?? '');

if ($username === '' || $password === '') {
    echo json_encode(["success" => false, "message" => "Required fields are missing."]);
    exit;
}

$query = "SELECT u.*, r.role_name 
          FROM Users_tb u
          INNER JOIN Roles_tb r ON u.role_id = r.role_id
          WHERE u.username = ?
          LIMIT 1";

$stmt = $conn->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo json_encode(["success" => false, "message" => "Invalid login credentials."]);
    exit;
}

$user = $result->fetch_assoc();

if (strtolower($user['role_name']) === "patient") {
    echo json_encode(["success" => false, "message" => "Patients must use the patient login."]);
    exit;
}

if (!password_verify($password, $user['password_hash'])) {
    echo json_encode(["success" => false, "message" => "Incorrect password."]);
    exit;
}

// ✅ Set session
$_SESSION['admin'] = [
    'user_id'  => $user['user_id'],
    'username' => $user['username'],
    'role'     => $user['role_name']
];

echo json_encode([
    "success" => true,
    "role" => $user['role_name'],
    "redirect" =>
        $user['role_name'] === 'Super Admin' ? "/admin-ui/admin-main.php" :
        ($user['role_name'] === 'Dentist' ? "/dentist-ui/dentist-main.php" :
        ($user['role_name'] === 'Front Desk' ? "/staff-ui/staff-frontdesk-main.php" :
        "/staff-ui/staff-assistant-main.php"))
]);
exit;
