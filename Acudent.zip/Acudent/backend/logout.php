<?php
// logout.php (Updated for hybrid auth: sessions + tokens)

header("Content-Type: application/json");  // Return JSON for API-style response
session_start();

// Include DB connection and token validation
$dbPath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';
$validatePath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/api/auth/validate-token/validate-token.php';  // Adjust if path differs

if (!file_exists($dbPath) || !file_exists($validatePath)) {
    echo json_encode(["success" => false, "message" => "Server error: Files missing."]);
    exit;
}

require_once $dbPath;
require_once $validatePath;

// Validate the token from the request (if provided)
$userId = validateToken();  // This checks the Authorization header

if ($userId) {
    // Delete the token from DB (removes all tokens for this user; adjust if needed)
    $deleteQuery = "DELETE FROM api_tokens WHERE user_id = ?";
    $stmt = $conn->prepare($deleteQuery);
    if ($stmt) {
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        // Optional: Log success/error
        if ($stmt->affected_rows > 0) {
            error_log("Token deleted for user_id: $userId");
        } else {
            error_log("No token found to delete for user_id: $userId");
        }
    } else {
        error_log("Token delete prepare failed: " . $conn->error);
    }
} else {
    // No valid token (optional: still proceed with session logout)
    error_log("Logout attempted without valid token");
}

// Clear session (always do this)
session_unset();
session_destroy();

// Return success (JS will handle redirect)
echo json_encode(['success' => true]);
exit;
?>