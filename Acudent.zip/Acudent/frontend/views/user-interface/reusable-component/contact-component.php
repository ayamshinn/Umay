  <!-- ================ Section 7 - Contact Us ====================== -->
            <section class=" section7">

                <div class="contact-us-main-container">

                    <div class="row row-cols-xxl-2 row-cols-xl-2 row-cols-lg-1 row-cols-md-1 row-cols-sm-1 row-cols-1 ">

                        <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 ">
                            <div
                                class="row row-cols-xxl-2 row-cols-xl-2-row-cols-lg-1 row-cols-md-1 row-cols-sm-1 row-cols-1 px-3">
                                <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12">
                                    <div class="contact-us-image-of-clinic-left-main-container">
                                        <div class="contact-us-image-of-clinic-container">
                                            <img src="../../../frontend/assets/images/user-interface/dental-look/Clinic1.png "
                                                alt="clinic picture">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">
                                    <div class="contact-us-image-of-clinic-right-main-container">
                                        <div class="contact-us-image-of-clinic-container">
                                            <img src="../../../frontend/assets/images/user-interface/dental-look/Clinic1.png "
                                                alt="clinic picture">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div
                                class="row row-cols-xxl-2 row-cols-xl-2-row-cols-lg-1 row-cols-md-1 row-cols-sm-1 row-cols-1 px-3 pt-4">
                                <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12">
                                    <div class="contact-us-image-of-clinic-lower-main-container">
                                        <div class="contact-us-image-of-clinic-container">
                                            <img src="../../../frontend/assets/images/user-interface/dental-look/Clinic1.png "
                                                alt="clinic picture">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12">
                                    <div class="contact-us-image-of-clinic-lower-main-container">
                                        <div class="contact-us-image-of-clinic-container">
                                            <img src="../../../frontend/assets/images/user-interface/dental-look/Clinic1.png "
                                                alt="clinic picture">
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>




                        <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div
                                class="contact-us-form-container-main-wrapper w-100 h-100 d-flex flex-column  justify-content-center align-items-center">
                                <div class="contact-us-header-container w-100   d-flex ms-auto">
                                    <div class="contact-us-header-wrapper d-flex ms-auto">
                                        <h5><i class="fa-regular fa-comment-dots"></i> Message Us</h5>
                                    </div>


                                </div>

                                <div class="contact-us-form-main-container w-100">
                                    <div class="contact-us-form-container d-flex flex-column justify-content-start align-items-start">
                                        <h3> Interact With Us</h3>
                                        <p>Get in touch with our team for inquiries, appointments, or assistance.</p>

                                    </div>


                                    <form class="simple-contact-form">

                                        <div class="simple-contact-form-wrapper">
                                            <label>Name:</label>
                                            <input type="text" class="line-input" required>
                                        </div>

                                        <div class="simple-contact-form-wrapper">
                                            <label>Email:</label>
                                            <input type="email" class="line-input" required>

                                        </div>

                                        <div class="simple-contact-form-wrapper-message">
                                            <label>Message:</label>
                                            <textarea id="message" rows="5" placeholder="Write your message"
                                                required></textarea>
                                        </div>


                                        <div class="submit-button d-flex ms-auto">
                                            <button type="submit" class="submit-btn d-flex ms-auto">SUBMIT</button>
                                        </div>


                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>