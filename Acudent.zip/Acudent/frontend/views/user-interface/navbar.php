  <header class="navbar-main-container">
            <!-- Top Nav -->
            <nav class="top-nav">
                <div class="top-nav-inner ">
                    <div class="row  ">
                        <div class="col">
                            <div class="left-col-top-nav  d-flex flex-row py-1">
                                <div
                                    class="social-media d-flex flex-row align-items-center justify-content-center ms-2 gap-2">

                                    <a href="" class="facebook"><i class="fa-brands fa-facebook"></i></a>
                                    <a href="" class="instagram"><i class="fa-brands fa-instagram"></i></i></a>
                                    <a href="" class="tiktok"><i class="fa-brands fa-tiktok"></i></a>
                                    <div class="phone-number">|<i class="fa-solid fa-phone ms-1 me-1"></i>09212775753
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="open-time-group py-1 ">

                                <div class=" ms-auto opentimelogo">
                                    <i class="fa-solid fa-clock"></i>
                                </div>
                                <div class="open-time">
                                    Opening Time: Monday to Sunday 9:00 AM - 5:00 PM
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </nav>

            <!-- Bottom Nav -->
            <nav class="bottom-nav-container">
                <div class="bottom-nav-inner ">
                    <div class="row align-items-center ">
                        <!-- Left: Logo -->
                        <div class="col d-flex justify-content-start align-items-center">
                            <a class="logo" href="#">
                                <img src="../../assets/images/user-interface/banners-images-logo/logo.png"
                                    alt="Clinic Logo" />
                                <div class="logo-text">
                                    <h3>MAPRU</h3>
                                    <h5>Dental Clinic</h5>
                                </div>
                            </a>
                        </div>

                        <!-- Right: Nav -->
                        <div class="col d-flex justify-content-end align-items-center ">
                            <div class="nav-links-container d-flex align-items-center ">
                                <ul class="nav-links">
                                    <li><a href="../user-interface/index.php" class="">Home</a></li>
                                    <li><a href="../user-interface/about.php">About</a></li>
                                    <li class="dropdown">
                                        <a href="../user-interface/services.php">Services </a>
                                        <button><i class="fa-solid fa-angle-down"></i></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="#">Teeth Cleaning</a></li>
                                            <li><a href="#">Dental Checkup</a></li>
                                            <li><a href="#">Braces & Orthodontics</a></li>
                                            <li><a href="#">Tooth Extraction</a></li>
                                        </ul>
                                    </li>

                                    <li><a href="../user-interface/dentists.php">Dentists</a></li>
                                    <li><a href="../user-interface/contact.php">Contact</a></li>
                                </ul>
                                <div class="nav-links-inner-btn-login ps-4">
                                    <button class="btn-signin" data-target="authentication-modal-container-id"><i
                                            class="fa-solid fa-right-to-bracket me-2"></i>Sign In</button>
                                </div>

                                <div class="nav-links-inner-btn-toggle-menu">
                                    <button class="btn-toggle-menu"><i class="fa-solid fa-bars"></i></button>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </nav>
        </header>