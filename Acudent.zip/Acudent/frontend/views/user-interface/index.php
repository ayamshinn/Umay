<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAPRU - Homepage</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../../assets/css/user-interface/index.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/navbar.css">
        <link rel="stylesheet" href="../../assets/css/user-interface/footer.css">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">



    <style>
        @import url('https://fonts.googleapis.com/css2?family=Pacifico&display=swap');
    </style>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap');
    </style>

</head>

<body>

    <div class="main-container overflow-hidden">
                
        <?php include '../user-interface/navbar.php'; ?>
      

        <div class="landing-page-content-main-container">
            <!----------Landing Page --------------->
            <!-- ============= Hero Banner =============== -->
            <section class="section1  ">
                <div class="slider">


                    <div class="list">

                        <div class="item">
                            <img src="../../assets/images/user-interface/banners-images-logo/mapru.png"
                                alt="mapru-1st-slide">

                            <div class="content">
                                <div class="header">Welcome to Mapru</div>

                                <div class="title">CREATING CONFIDENT</div>
                                <div class="type">SMILE</div>
                                <div class="description">
                                    At MAPRU Dental Clinic, we combine modern dentistry with a personal touch,
                                    tailoring every treatment to your unique needs.
                                </div>
                                <div class="makeappointment-btn">
                                    <button>Book An Appointment</button>
                                </div>
                            </div>
                        </div>



                        <div class="item">
                            <img src="../../assets/images/user-interface/banners-images-logo/hero-banner4.webp"
                                alt="mapru-1st-slide">

                            <div class="content">
                                <div class="header">Welcome to Mapru</div>

                                <div class="title">CLEAN HYGIENE</div>
                                <div class="type">CARE</div>
                                <div class="description">
                                    We ensure safe and sanitized dental tools for every procedure.
                                    Your comfort and safety are always our top priority.
                                </div>
                                <div class="makeappointment-btn">
                                    <button>Book An Appointment</button>
                                </div>
                            </div>
                        </div>

                        <div class="item">
                            <img src="../../assets/images/user-interface/banners-images-logo/hero-banner1.jpg"
                                alt="mapru-1st-slide">

                            <div class="content">
                                <div class="header">Welcome to Mapru</div>
                                <div class="title">BRIGHT CONFIDENT</div>
                                <div class="type">SMILES</div>
                                <div class="description">
                                    We help you achieve a naturally beautiful smile that shines.
                                    Experience dental care designed for comfort and trust.
                                </div>
                                <div class="makeappointment-btn">
                                    <button>Book An Appointment</button>
                                </div>
                            </div>
                        </div>

                        <div class="item">
                            <img src="../../assets/images/user-interface/banners-images-logo/hero-banner6.webp"
                                alt="mapru-1st-slide">

                            <div class="content">
                                <div class="header">Welcome to Mapru</div>

                                <div class="title">SMART CHECK</div>
                                <div class="type">X-RAY</div>
                                <div class="description">
                                    MAPRU Dental Bacoor uses digital X-rays for fast and accurate results.
                                    Your diagnosis is clearer, safer, and more precise.
                                </div>
                                <div class="makeappointment-btn">
                                    <button>Book An Appointment</button>

                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <img src="../../assets/images/user-interface/banners-images-logo/hero-banner2.webp"
                                alt="mapru-1st-slide">

                            <div class="content">
                                <div class="header">Welcome to Mapru</div>
                                <div class="title">SMILE GUIDE</div>
                                <div class="type">EDUCATION</div>
                                <div class="description">
                                    We educate Bacoor patients using real dental models for clarity.
                                    Learn proper care and protect your smile with MAPRU experts.
                                </div>
                                <div class="makeappointment-btn">
                                    <button>Book An Appointment</button>
                                </div>
                            </div>
                        </div>

                    </div>


                    <div class="thumbnail ">
                        <div class="item">
                            <img src="../../assets/images/user-interface/banners-images-logo/mapru.png"
                                alt="mapru-1st-slide">
                        </div>

                        <div class="item">
                            <img src="../../assets/images/user-interface/banners-images-logo/hero-banner4.webp"
                                alt="mapru-1st-slide">
                        </div>
                        <div class="item">
                            <img src="../../assets/images/user-interface/banners-images-logo/hero-banner1.jpg"
                                alt="mapru-1st-slide">
                        </div>


                        <div class="item">
                            <img src="../../assets/images/user-interface/banners-images-logo/hero-banner6.webp"
                                alt="mapru-1st-slide">
                        </div>
                        <div class="item">
                            <img src="../../assets/images/user-interface/banners-images-logo/hero-banner2.webp"
                                alt="mapru-1st-slide">
                        </div>

                    </div>


                    <div class="nextPrevArrows ">
                        <button class="prev">
                            < </button>
                                <button class="next"> > </button>
                    </div>


                </div>
            </section>


            <!-- ================= Section 2 - About us ====================== -->
            <section class="section2 ">
                <div class="about-us-container">
                    <div class="about-us-container-inner">
                        <div
                            class="row  row-cols-xxl-2 row-cols-xl-2 row-cols-lg-1 row-cols-md-1 row-cols-sm-1 row-cols-1">
                            <div class="col-left col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                <div class="photo-frame  ">

                                    <!-- Behind Frame -->
                                    <div class="photo-behind">
                                        <img src="../../assets/images/user-interface/banners-images-logo/hero-banner0.jpg"
                                            class="slide">
                                        <img src="../../assets/images/user-interface/banners-images-logo/hero-banner5.jpg"
                                            class="slide">
                                    </div>

                                    <!-- Front Frame -->
                                    <div class="photo-front">
                                        <img src="../../assets/images/user-interface/banners-images-logo/hero-banner0.jpg"
                                            class="slide">
                                        <img src="../../assets/images/user-interface/banners-images-logo/hero-banner5.jpg"
                                            class="slide">
                                    </div>


                                </div>
                            </div>
                            <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                <div class="about-us-col-right-container">
                                    <div class="about-us-col-right-inner">
                                        <div class="about-us-text-container">
                                            <div class="about-us-text-inner">

                                                <div class="about-us-text-title-header">
                                                    <div class="about-us-text-title-header-inner">
                                                        <h5>About Us</h5>
                                                    </div>
                                                </div>
                                                <hr class="hori-line m-0">

                                                <div class="about-us-text-phrase-header">
                                                    <div class="about-us-text-phrase-header-inner py-3">
                                                        <h2>Trusted Family Dentistry in Bacoor, Cavite</h2>
                                                        <h2>Where Comfort Meets Quality Dental Care</h2>
                                                    </div>
                                                </div>
                                                <div class="about-us-text-content">
                                                    <div class="about-us-text-content-inner">
                                                        <p> Dental Clinic is a trusted dental care provider located
                                                            in Bacoor,
                                                            Cavite led by Dra. Maja Prudente. Dedicated to delivering
                                                            quality,
                                                            affordable, and patient-centered oral healthcare, the clinic
                                                            serves
                                                            both children and adults with a wide range of dental
                                                            services tailored
                                                            to meet individual needs.
                                                            <br>
                                                            <br>
                                                            From routine checkups and cleanings to more advanced
                                                            treatments like braces,
                                                            root canal therapy, dental implants, and crowns, MAPRU
                                                            Dental Clinic combines
                                                            professional expertise with a warm and welcoming
                                                            environment.
                                                        </p>
                                                    </div>
                                                </div>

                                                <div
                                                    class="row row-cols-xxl-2 row-cols-xl-2 row-cols-lg-1 row-cols-md-1 row-cols-sm-1 row-cols-1 py-3">
                                                    <div
                                                        class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">

                                                        <div class="about-us-text-incontainer-inner-left px-4 ">
                                                            <h4><i class="fa-solid fa-bullseye me-2"></i>Mission</h4>
                                                            <p>
                                                                To provide ethical, reliable, and compassionate dental
                                                                care through skilled professionals committed to patient
                                                                comfort and well-being.
                                                            </p>
                                                        </div>
                                                    </div>

                                                    <div
                                                        class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">
                                                        <div class="about-us-text-incontainer-right px-4 ">
                                                            <h4><i class="fa-regular fa-eye me-2"></i>Vision</h4>
                                                            <p>
                                                                To be a trusted dental clinic known for professional
                                                                excellence, modern practice, and genuine care for every
                                                                smile.
                                                        </div>
                                                    </div>

                                                </div>
                                                <div class="about-us-more-details-container d-flex">
                                                    <div class="about-us-more-details-container-inner d-flex ms-auto">
                                                        <button class=" about-us-btn border-none p-0 m-0">More details<i
                                                                class="ms-1 fa-solid fa-angles-right"></i></button>
                                                    </div>
                                                </div>


                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </section>

            <!-- ===================== Section 3 - Meet The Doctors ============================ -->

            <section class="section3">
                <div class="doctors-container h-100   ">
                    <div class="doctors-container-inner">
                        <div
                            class="row row-cols-xxl-2 row-cols-xl-2 row-cols-lg-1 row-cols-md-1 row-cols-sm-1 row-cols-1 ">
                            <div class="col  col-xxl-7 col-xl-7 col-lg-12 col-md-12 col-sm-12">
                                <div class="doctors-col-left-container">
                                    <div class="doctors-col-left-inner">
                                        <div class="doctors-col-left-text-container ">
                                            <div class="doctors-text-header">
                                                <div class="doctors-text-header-inner">
                                                    <h5>Our Expert Team</h5>
                                                    <h2>Meet the Doctors</h2>

                                                </div>
                                            </div>
                                            <div class="doctors-text-content pe-5">
                                                <div class="doctors-text-content-inner">
                                                    <p>Behind MAPRU’s trusted care is a team of dedicated dental
                                                        professionals who combine skill, experience, and integrity.
                                                        Each doctor plays a vital role in ensuring every patient
                                                        receives safe, reliable, and confident treatment.

                                                    </p>
                                                    <hr class="hori-line my-4">
                                                    <div class="doctors-text-content-row">
                                                        <div class="row row-cols-2 g-4">

                                                            <div class="col doctors-text-content-row-item ">
                                                                <h4><i class="fa-solid fa-check"></i> Clinical
                                                                    Expertise</h4>
                                                                <p>
                                                                    Our doctors are trained across various dental
                                                                    disciplines, allowing them to handle treatments with
                                                                    accuracy and confidence.
                                                                </p>
                                                            </div>

                                                            <div class="col doctors-text-content-row-item">
                                                                <h4><i class="fa-solid fa-check"></i>
                                                                    Professional Integrity</h4>
                                                                <p>
                                                                    Every decision is guided by ethical practice and
                                                                    honesty, ensuring patients receive only the care
                                                                    they truly need.
                                                                </p>
                                                            </div>

                                                            <div class="col doctors-text-content-row-item">
                                                                <h4><i class="fa-solid fa-check"></i> Continuous
                                                                    Development</h4>
                                                                <p>
                                                                    Our team actively refines their skills through
                                                                    ongoing learning to stay current with modern dental
                                                                    standards.
                                                                </p>
                                                            </div>

                                                            <div class="col doctors-text-content-row-item">
                                                                <h4><i class="fa-solid fa-check"></i> Trusted
                                                                    Experience</h4>
                                                                <p>
                                                                    Years of hands-on practice allow our doctors to
                                                                    deliver consistent, dependable care patients can
                                                                    rely on.
                                                                </p>
                                                            </div>

                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                            <div class="doctors-learn-more-container py-4">
                                                <button class="doctor-learn-mor-bn">
                                                    Learn More<i class="ms-2 fa-solid fa-angles-right"></i>
                                                </button>
                                            </div>
                                            <div class="doctors-bottom-phrase mt-4">
                                                <div class="doctors-bottom-phrase-inner">
                                                    <h2>The <span>Experts</span></h2>
                                                    <h2>Behind Your <span>Smile</span></h2>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col col-xxl-5 col-xl-5 col-lg-12 col-md-12 col-sm-12">

                                <div class="doctors-col-right-container  ">
                                    <div class="doctors-col-right-container-inner ps-5">
                                        <div
                                            class="row  row-cols-xxl-2 row-cols-xl-2 row-cols-lg-2 row-cols-md-1 row-cols-sm-1 row-cols-1 row-doctor">
                                            <div class="col col-first">
                                                <div class="doctor-img-container">
                                                    <div class="doctor-img-inner">
                                                        <img src="../../assets/images/user-interface/doctors/Dra.maja1.jpg"
                                                            alt="">

                                                        <div class="doctor-info-container">
                                                            <div class="doctor-info-socials">
                                                                <i class="fa-brands fa-linkedin"></i>
                                                                <a href=""></a>
                                                            </div>
                                                            <div class="doctor-info-wrapper">
                                                                <p>Dr. Maja Prudente</p>
                                                                <p class="doctor-info">Orthodontics</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="col col-second">
                                                <div class="doctor-img-container">
                                                    <div class="doctor-img-inner"><img
                                                            src="../../assets/images/user-interface/doctors/dr.Renz.jpg"
                                                            alt=""></div>
                                                </div>
                                            </div>
                                            <div class="col">
                                                <div class="doctor-img-container">
                                                    <div class="doctor-img-inner"><img
                                                            src="../../assets/images/user-interface/doctors/Dr.Jano2.jpg"
                                                            alt=""></div>
                                                </div>
                                            </div>
                                            <div class="col">
                                                <div class="doctor-img-container">
                                                    <div class="doctor-img-inner"><img
                                                            src="../../assets/images/user-interface/doctors/Dr.Ruth.jpg"
                                                            alt=""></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
            </section>

            <!-- ==================== Section 4 - Services ========================== -->
            <section class="section4 ">
                <div class="services-main-container ">
                    <div class="services-main-container-header d-flex flex-column text-center">
                        <div class="services-main-container-title text-center">
                            <h5>Services</h5>
                        </div>
                        <h2>Explore Our Dental Services</h2>
                        <div class="services-main-container-des  text-center">
                            <p>Quality Dental Solutions for All Age</p>
                        </div>
                    </div>

                    <div class="services-main-container-inner  ">
                        <div class="hexagon-container">
                            <div class="hexagon-container-inner ">
                                <div class="hexagon-container-left-col hexagon">
                                    <div class="hexagon-cell"><img
                                            src="../../assets/images/user-interface/banners-images-logo/general dentistry.webp"
                                            alt="">
                                        <div class="services-list-container">
                                            <div class="services-main-category"> <span>Surgical Treatment</span>
                                            </div>
                                            <div class="services-sub-category">
                                                <ul>
                                                    <li>Tooth Extraction</li>
                                                    <li>Odontectomy</li>

                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="hexagon-container-right-col">
                                    <div class="beside-hex-header">
                                        <h1>Intervene</h1>
                                    </div>
                                    <div class="beside-hex-des">
                                        <p>Performs precise surgical procedures to address complex dental issues,
                                            ensuring proper function and oral health.</p>
                                    </div>
                                    <div class="learn-more-services-btn-container">
                                        <button class="learn-more-btn">Learn More</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="hexagon-container">
                            <div class="hexagon-container-inner ">
                                <div class="hexagon-container-left-col">
                                    <div class="beside-hex-header">
                                        <h1>Enhance</h1>
                                    </div>
                                    <div class="beside-hex-des">
                                        <p>Improves the overall appearance of teeth and smile through aesthetic-focused
                                            dental treatments.</p>
                                    </div>
                                    <div class="learn-more-services-btn-container">
                                        <button class="learn-more-btn">Learn More</button>
                                    </div>
                                </div>
                                <div class="hexagon-container-right-col hexagon">
                                    <div class="hexagon-cell ms-auto"><img
                                            src="../../assets/images/user-interface/banners-images-logo/cosmetic-dentistry.webp"
                                            alt="">
                                        <div class="services-list-container">
                                            <div class="services-main-category"> <span>Cosmetic Dentistry</span>
                                            </div>
                                            <div class="services-sub-category">
                                                <ul>
                                                    <li>Tooth Filling</li>
                                                    <li>Tooth Whitening</li>
                                                    <li>Cosmetic Bonding</li>
                                                </ul>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="hexagon-container">
                            <div class="hexagon-container-inner ">
                                <div class="hexagon-container-left-col hexagon">
                                    <div class="hexagon-cell"><img
                                            src="../../assets/images/user-interface/banners-images-logo/prosthodontics.webp"
                                            alt="">
                                        <div class="services-list-container">
                                            <div class="services-main-category"> <span>Prosthodontics</span>
                                            </div>
                                            <div class="services-sub-category">
                                                <ul>
                                                    <li>Fixed Denture</li>
                                                    <li>Partial Denture</li>
                                                    <li>Complete Denture</li>

                                                </ul>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="hexagon-container-right-col">
                                    <div class="beside-hex-header">
                                        <h1>Restore</h1>
                                    </div>
                                    <div class="beside-hex-des">
                                        <p>Replaces or rebuilds missing or damaged teeth using specialized restorative
                                            procedures.</p>
                                    </div>
                                    <div class="learn-more-services-btn-container">
                                        <button class="learn-more-btn">Learn More</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="hexagon-container">
                            <div class="hexagon-container-inner ">
                                <div class="hexagon-container-left-col">
                                    <div class="beside-hex-header">
                                        <h1>Protect</h1>
                                    </div>
                                    <div class="beside-hex-des">
                                        <p>Focuses on preserving gum and bone health to prevent diseases that can
                                            compromise long-term oral stability.</p>
                                    </div>
                                    <div class="learn-more-services-btn-container">
                                        <button class="learn-more-btn">Learn More</button>
                                    </div>
                                </div>
                                <div class="hexagon-container-right-col hexagon">
                                    <div class="hexagon-cell ms-auto"><img
                                            src="../../assets/images/user-interface/banners-images-logo/periodontics.webp"
                                            alt="">
                                        <div class="services-list-container">
                                            <div class="services-main-category"> <span>Periodontics</span>
                                            </div>
                                            <div class="services-sub-category">
                                                <ul>
                                                    <li>Oral Prophylaxis</li>
                                                    <li>Deep Scaling</li>

                                                </ul>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="hexagon-container ">
                            <div class="hexagon-container-inner ">
                                <div class="hexagon-container-left-col hexagon">
                                    <div class="hexagon-cell"><img
                                            src="../../assets/images/user-interface/banners-images-logo/orthodontics.webp"
                                            alt="">
                                        <div class="services-list-container">
                                            <div class="services-main-category"> <span>Orthodontics</span>
                                            </div>
                                            <div class="services-sub-category">
                                                <ul>
                                                    <li>Metal Braces</li>
                                                    <li>Ceramic Braces</li>
                                                    <li>Self-Ligating Braces</li>

                                                </ul>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="hexagon-container-right-col">
                                    <div class="beside-hex-header">
                                        <h1>Align</h1>
                                    </div>
                                    <div class="beside-hex-des">
                                        <p>Corrects tooth alignment and bite issues to achieve a straighter and
                                            healthier smile.</p>
                                    </div>
                                    <div class="learn-more-services-btn-container">
                                        <button class="learn-more-btn">Learn More</button>
                                    </div>
                                </div>
                            </div>
                        </div>



                    </div>

                </div>
            </section>

            <!-- ================== Section 5 - Why Choose Us ========================== -->
            <section class="section5">

                <div class="why-choose-main-container">
                    <div class="why-choose-main-container-header">
                        <div class="why-choose-main-container-title text-center">
                            <h5>Our Difference</h5>
                        </div>

                        <h2>Why Choose MAPRU Dental Clinic?</h2>





                        <div class="why-choose-main-container-header-text">
                            <p>Our clinic combines modern dental technology with a clean, welcoming space designed to
                                put you at ease. We believe that exceptional care should be both accessible and
                                affordable, and we’re proud to serve individuals and families who value a thoughtful,
                                patient-centered approach. At MAPRU Dental Clinic , we don’t just treat
                                teeth—we care for
                                people, and we’re here to help you achieve a healthy, confident smile that lasts.</p>
                        </div>
                    </div>
                    <div class="why-choose-container-inner g-3">
                        <div class="why-choose-container-row d-flex flex-column justify-content-center ">

                            <div class="why-choose-col-right">

                                <div
                                    class="row g-4 row-cols-xxl-3 row-cols-xl-3  row-cols-lg-3 row-cols-md-2 row-cols-sm-2 row-cols-1 py-3 ">

                                    <div class="col grid-col">
                                        <div class="grid-item">
                                            <div class="grid-img-container ">
                                                <i class="fa-solid fa-user-check"></i>
                                            </div>
                                            <h3>Personalized Dental Care</h3>
                                            <p>Your smile is personal, and your dental care should be too.</p>
                                        </div>
                                    </div>
                                    <div class="col  grid-col">

                                        <div class="grid-item">
                                            <div class="grid-img-container ">
                                                <i class="fa-solid fa-people-group"></i>
                                            </div>
                                            <h3>Expert & Compassionate Team</h3>
                                            <p>Dra. Maja Prudente leads a skilled team committed to honest,
                                                compassionate dental care.</p>
                                        </div>
                                    </div>
                                    <div class="col grid-col">
                                        <div class="grid-item">
                                            <div class="grid-img-container">
                                                <i class="fa-solid fa-users"></i>
                                            </div>
                                            <h3>Patient-Focused Approach</h3>
                                            <p>We listen, explain clearly, and support you throughout your
                                                treatment.</p>
                                        </div>
                                    </div>
                                    <div class="col grid-col">
                                        <div class="grid-item">
                                            <div class="grid-img-container">
                                                <i class="fa-solid fa-tooth"></i>
                                            </div>
                                            <h3>Comprehensive Dental Services</h3>
                                            <p>From checkups to advanced procedures, expect personalized,
                                                friendly care.</p>
                                        </div>
                                    </div>
                                    <div class="col grid-col">
                                        <div class="grid-item">
                                            <div class="grid-img-container">
                                                <i class="fa-solid fa-people-roof"></i>
                                            </div>
                                            <h3>Community-Focused Care</h3>
                                            <p>We're part of your local community, offering family-friendly
                                                services and support for all ages.</p>
                                        </div>
                                    </div>
                                    <!-- New Item 6 -->
                                    <div class="col grid-col">
                                        <div class="grid-item">
                                            <div class="grid-img-container">
                                                <i class="fa-solid fa-people-arrows"></i>
                                            </div>
                                            <h3>Affordable & Accessible Care</h3>
                                            <p>Quality dental care that fits your budget, with flexible payment
                                                options.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="conclusion-statement mt-4 text-center">
                                <p>With our commitment to innovation and trust, we ensure every visit leaves you
                                    feeling empowered and informed.<br>
                                    Join the MAPRU family for dental excellence that grows with you—schedule your
                                    next checkup now.</p>
                            </div> -->

                    </div>
                </div>


            </section>

            <!-- =================== Section 6 - Testimonials ======================= -->
            <section class="section6">
                <div class="testimonial-main-container ">
                    <div class="testimonial-header">
                        <h5>Word of Mouth</h5>
                        <h2>Why They Choose Us?</h2>
                        <p>Real experiences from our patients. Discover why they continue to choose our clinic.</p>
                    </div>

                    <div class="testimonial-slider-container">
                        <div class="testimonial-wrapper" id="testimonialWrapper"></div>
                    </div>

                    <div class="testimonial-pagination" id="pagination"></div>
                </div>
            </section>


            <!-- =================== Section 6.5 - FAQ ======================= -->

            <section class="section-65">
                <div class="faq-main-container">
                    <div class="faq-main-container-inner">
                        <div class="row row-cols-2">
                            <div class="col col-5">
                                <div class="faq-col-left">
                                    <div class="faq-col-left-inner w-100">
                                        <div class="faq-header">
                                            <h5>Frequently Asked Questions<i
                                                    class="fa-regular fa-circle-question ms-1"></i></h5>
                                            <h2>Everything</h2>
                                            <h2>You Need to Know</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col col-7">
                                <div class="faq-col-right">
                                    <div class="faq-col-right-inner">
                                        <div class="faq-content">
                                            <div class="faq-list">
                                                <div class="faq-item">
                                                    <div class="faq-question">
                                                        <button>How often should I visit the dentist?</button>
                                                        <div class="faq-questionn-icon">
                                                            <i class="fa-solid fa-angle-down"></i>
                                                        </div>
                                                    </div>
                                                    <div class="faq-answer">
                                                        <p>We recommend visiting the dentist at least twice a year for
                                                            check-ups and cleanings.</p>
                                                    </div>
                                                </div>

                                                <div class="faq-item">
                                                    <div class="faq-question">
                                                        <button>What should I do in a dental emergency?</button>
                                                        <div class="faq-questionn-icon">
                                                            <i class="fa-solid fa-angle-down"></i>
                                                        </div>
                                                    </div>
                                                    <div class="faq-answer">
                                                        <p>Contact us immediately. We provide urgent care to address
                                                            pain, broken teeth, or other dental emergencies.</p>
                                                    </div>
                                                </div>

                                                <div class="faq-item">
                                                    <div class="faq-question">
                                                        <button>Do you offer services for kids?</button>
                                                        <div class="faq-questionn-icon">
                                                            <i class="fa-solid fa-angle-down"></i>
                                                        </div>
                                                    </div>
                                                    <div class="faq-answer">
                                                        <p>Yes! We provide child-friendly dental services for kids of
                                                            all ages.</p>
                                                    </div>
                                                </div>

                                                <div class="faq-item">
                                                    <div class="faq-question">
                                                        <button>What are my options for replacing missing
                                                            teeth?</button>
                                                        <div class="faq-questionn-icon">
                                                            <i class="fa-solid fa-angle-down"></i>
                                                        </div>
                                                    </div>
                                                    <div class="faq-answer">
                                                        <p>We offer dental implants, bridges, and dentures depending on
                                                            your needs.</p>
                                                    </div>
                                                </div>

                                                <div class="faq-item">
                                                    <div class="faq-question">
                                                        <button>Is teeth whitening safe?</button>
                                                        <div class="faq-questionn-icon">
                                                            <i class="fa-solid fa-angle-down"></i>
                                                        </div>
                                                    </div>
                                                    <div class="faq-answer">
                                                        <p>Yes, professional teeth whitening under supervision is safe
                                                            and effective.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <!-- ================ Section 7 - Contact Us ====================== -->
            <section class=" section7">

                <div class="contact-us-main-container">

                    <div class="row row-cols-xxl-2 row-cols-xl-2 row-cols-lg-1 row-cols-md-1 row-cols-sm-1 row-cols-1 ">

                        <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12">
                            <div
                                class="row row-cols-xxl-2 row-cols-xl-2-row-cols-lg-1 row-cols-md-1 row-cols-sm-1 row-cols-1 px-3">
                                <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12">
                                    <div class="contact-us-image-of-clinic-left-main-container">
                                        <div class="contact-us-image-of-clinic-container">
                                            <img src="../../../frontend/assets/images/user-interface/dental-look/Clinic1.png "
                                                alt="clinic picture">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">
                                    <div class="contact-us-image-of-clinic-right-main-container">
                                        <div class="contact-us-image-of-clinic-container">
                                            <img src="../../../frontend/assets/images/user-interface/dental-look/Clinic1.png "
                                                alt="clinic picture">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div
                                class="row row-cols-xxl-2 row-cols-xl-2-row-cols-lg-1 row-cols-md-1 row-cols-sm-1 row-cols-1 px-3 py-3">
                                <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12">
                                    <div class="contact-us-image-of-clinic-lower-main-container">
                                        <div class="contact-us-image-of-clinic-container">
                                            <img src="../../../frontend/assets/images/user-interface/dental-look/Clinic1.png "
                                                alt="clinic picture">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12">
                                    <div class="contact-us-image-of-clinic-lower-main-container">
                                        <div class="contact-us-image-of-clinic-container">
                                            <img src="../../../frontend/assets/images/user-interface/dental-look/Clinic1.png "
                                                alt="clinic picture">
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>




                        <div class="col-xxl-6 col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div
                                class="contact-us-form-container-main-wrapper w-100 h-100 d-flex flex-column  justify-content-center align-items-center">
                                <div class="contact-us-header-container w-100   d-flex ms-auto">
                                    <div class="contact-us-header-wrapper d-flex ms-auto">
                                        <p>Interact With Us</p>
                                    </div>


                                </div>

                                <div class="contact-us-form-main-container w-100">
                                    <div class="contact-us-form-container">
                                        <h3>Contact Us</h3>
                                    </div>

                                    <form class="simple-contact-form">

                                        <div class="simple-contact-form-wrapper">
                                            <label>Name:</label>
                                            <input type="text" class="line-input" required>
                                        </div>

                                        <div class="simple-contact-form-wrapper">
                                            <label>Email:</label>
                                            <input type="email" class="line-input" required>

                                        </div>

                                        <div class="simple-contact-form-wrapper-message">
                                            <label>Message:</label>
                                            <textarea id="message" rows="5" placeholder="Write your message"
                                                required></textarea>
                                        </div>


                                        <div class="submit-button d-flex ms-auto">
                                            <button type="submit" class="submit-btn d-flex ms-auto">SUBMIT</button>
                                        </div>


                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- ================ Section 8 - Visit Us ====================== -->
            <section class="section8">

                <div class="visit-us-main-container">
                    <div class="visit-us-header-container text-center">
                        <h5>Visit Us</h5>
                        <h3>Where to Find MAPRU Dental Clinic?</h3>
                        <div class="visit-us-header-paragraph">
                            <p>Come in and experience personalized dental care in a comfortable, welcoming space.</p>
                        </div>
                    </div>


                    <div class="map-container py-3">
                        <div class="map-wrapper">
                            <iframe
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3864.0731381231135!2d120.95002119999998!3d14.422947299999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397d25b9c7a8d79%3A0xf33a33d44be4864!2sMAPRU%20Dental%20Clinic!5e0!3m2!1sen!2sph!4v1764849277750!5m2!1sen!2sph"
                                width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>

                    <div class="map-container-brief-history py-3">
                        <p>MAPRU Dental Clinic is a community-focused practice in Bacoor, Cavite, committed to providing
                            compassionate and patient-centered dental care.
                            Their social media highlights a range of accessible services, including general dentistry,
                            esthetics, clear aligners, and dentures.
                            They actively engage with patients online, sharing real treatment results to build trust.
                            Although their exact beginnings aren’t detailed, their posts reflect a strong purpose of
                            serving local families with modern, quality care.



                        </p>
                    </div>
                </div>
            </section>

        </div>
        <!-- =================== Footer ========================= -->
       
<?php include '../user-interface/footer.php'; ?>

    </div>





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../../assets/js/user-interface/app.js"></script>
    <script src="../../assets/js/user-interface/navbar.js"></script>
    <script src="../../assets/js/user-interface/index.js"></script>
    <script src="../../assets/js/user-interface/footer.js"></script>



</body>

</html>