<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../../assets/css/user-interface/about_doctors.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/auth.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/footer.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/navbar.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <style>
@import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap');
</style>

    <title>MAPRU - Dentist</title>
</head>
<body>
   
   <?php include '../user-interface/navbar.php'; ?>

   <?php include '../../PHP/user-interface/auth.php'; ?>
  <!-- ======================================================================================================================================= -->


  <!--Sign In Popup Modal-->
  <div id="authentication-modal-container"></div>
  <script src="../../assets/js/user-interface/auth-loader.js"></script>


  <!--Sign In Popup Modal-->

  <!-- ======================================================================================================================================= -->


    <div class="banner">
        <img src="../../assets/images/user-interface/banners-images-logo/doctor_about.jpg" alt="Banner_Image">
        <div class="bottom-left-container">
        <div class ="bottom-left">Caring hands begin with <br> passionate dental experts</div>
       <button id="Appointment">Schedule an Appointment</button>
       </div>
    </div>

    <section class="Doctor_team">
         <h2>Meet the Team</h2>
    <div class="Team">
        <div class="border">
        <img src="../../assets/images/user-interface/doctors/Doctor's Team.png" class="team-doctor" alt="Doctor's team pic">
    </div>
</div>
    </section>

   

<section id="maja"> 
  <div class="maja-container">
    
    <!-- Image with border -->
    <div class="border-detail">
      <img src="../../assets/images/user-interface/doctors/Dr.Maja.jpg" alt="Picture of Mapru">
    </div>

    <!-- Text on clean background -->
    <div class="details">
      <h3>Dr. Maja Prudente</h3>
      <p>Dr. Maja Prudente is the Owner and Chief Dentist of MAPRU Dental Clinic in Bacoor, Cavite, and 
        also serves as a dentist at South Imus Specialists Hospital. She earned her Doctor of Dental Medicine 
        degree from Centro Escolar University and previously completed a Bachelor’s Degree in Nursing Education at Manila Doctors College. 
        With years of experience in both hospital and private practice, she is dedicated to providing quality dental care with a 
        focus on patient comfort and overall oral health.
        <br>
        <br>
        Beyond her academic background, Dr. Prudente has pursued specialized training in orthodontics, oral surgery, hospital dentistry, 
        and dental sleep medicine, enhancing her ability to offer comprehensive treatments to her patients. 
        Her commitment to continuous learning and compassionate care reflects in her work, making her a trusted professional in the dental community.</p>
    </div>

  </div>
</section>


<section id="renz">
    <div class="renz-container">
<div class="details-renz">
    
  <h3>Dr. Renz</h3>
        <p>Dr. Maja Prudente is the Owner and Chief Dentist of MAPRU Dental Clinic in Bacoor, Cavite, and 
        also serves as a dentist at South Imus Specialists Hospital. She earned her Doctor of Dental Medicine 
        degree from Centro Escolar University and previously completed a Bachelor’s Degree in Nursing Education at Manila Doctors College. 
        With years of experience in both hospital and private practice, she is dedicated to providing quality dental care with a 
        focus on patient comfort and overall oral health.
        <br>
        <br>
        Beyond her academic background, Dr. Prudente has pursued specialized training in orthodontics, oral surgery, hospital dentistry, 
        and dental sleep medicine, enhancing her ability to offer comprehensive treatments to her patients. 
        Her commitment to continuous learning and compassionate care reflects in her work, making her a trusted professional in the dental community.</p>
    </div>

    <div class="border-detail-renz">
    <img src="../../assets/images/user-interface/doctors/dr.Renz.jpg" alt="Picture of Renz">
</div>
  </div>

</section>

<section id="irish">
    <div class="irish-container">
        <div class="border-detail-irish">
            <img src="../../assets/images/user-interface/doctors/Dr.Ruth.jpg" alt="Picture of Irish">
        </div>
    <div class="details-irish">
  <h3>Dr. Irish</h3>
  <p>Dr. Maja Prudente is the Owner and Chief Dentist of MAPRU Dental Clinic in Bacoor, Cavite, and 
        also serves as a dentist at South Imus Specialists Hospital. She earned her Doctor of Dental Medicine 
        degree from Centro Escolar University and previously completed a Bachelor’s Degree in Nursing Education at Manila Doctors College. 
        With years of experience in both hospital and private practice, she is dedicated to providing quality dental care with a 
        focus on patient comfort and overall oral health.
        <br>
        <br>
        Beyond her academic background, Dr. Prudente has pursued specialized training in orthodontics, oral surgery, hospital dentistry, 
        and dental sleep medicine, enhancing her ability to offer comprehensive treatments to her patients. 
        Her commitment to continuous learning and compassionate care reflects in her work, making her a trusted professional in the dental community.</p>
    </div>
  </div>
</section>

<section id="jano">
    <div class="jano-container">
<div class="details-jano">
    
  <h3>Dr. Renz</h3>
        <p>Dr. Maja Prudente is the Owner and Chief Dentist of MAPRU Dental Clinic in Bacoor, Cavite, and 
        also serves as a dentist at South Imus Specialists Hospital. She earned her Doctor of Dental Medicine 
        degree from Centro Escolar University and previously completed a Bachelor’s Degree in Nursing Education at Manila Doctors College. 
        With years of experience in both hospital and private practice, she is dedicated to providing quality dental care with a 
        focus on patient comfort and overall oral health.
        <br>
        <br>
        Beyond her academic background, Dr. Prudente has pursued specialized training in orthodontics, oral surgery, hospital dentistry, 
        and dental sleep medicine, enhancing her ability to offer comprehensive treatments to her patients. 
        Her commitment to continuous learning and compassionate care reflects in her work, making her a trusted professional in the dental community.</p>
    </div>

    <div class="border-detail-jano">
    <img src="assets/images/dr.Renz.jpg" alt="Picture of Renz">
</div>
  </div>





<!--Footer Section-->
<div id="footer"></div>
<script src="../../assets/js/user-interface/footer.js"></script>

<script src="../../assets/js/user-interface/navbar.js"></script>
<!--Footer Section-->

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>


</body>
</html>