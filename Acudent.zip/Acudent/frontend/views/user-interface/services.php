<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAPRU - Services</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../../assets/css/user-interface/services.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/navbar.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/footer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Pacifico&display=swap');
    </style>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap');
    </style>

</head>

<body>

    <div class="main-container overflow-hidden">

        <?php include '../user-interface/navbar.php'; ?>


        <div class="landing-page-content-main-container">
            <!----------Landing Page --------------->


            <section class="section1 d-flex flex-column justify-content-center align-items-center">

                <div class="services-hero-banner w-100 ">
                    <div
                        class="services-hero-banner-inner d-flex flex-column justify-content-center align-items-center">
                        <div class="services-hero-banner-title">
                            <h1>Explore Our Services</h1>
                        </div>
                        <hr class="hori-line">
                        <div
                            class="services-hero-banner-sub mt-4 d-flex flex-row w-100 justify-content-center align-items-center gap-3">
                            <div class="services-hero-banner-sub-left d-flex flex-row">
                                <h5> <a href="../user-interface/index.php"><i
                                            class="fa-solid fa-house me-2"></i>Home</a> <i
                                        class="fa-solid fa-chevron-right mx-3"></i></h5>


                            </div>
                            <div class="services-hero-banner-sub-right">
                                <h5>Services</h5>

                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- =========================== Section 2 ===================================== -->
            <section class="section2">
                <div class="services-banner2-main-container ">
                    <div class="services-banner2-inner  py-4">
                        <div class="row g-3">
                            <div class="col-md-6  ">
                                <div class="services-banner2-col-left">
                                    <div class="services-banner2-col-left-inner">
                                        <div class="services-banner2-col-left-img">
                                            <img src="../../assets/images/user-interface/banners-images-logo/second banner.jpg"
                                                alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="services-banner2-col-right-inner">
                                    <div class="services-col-container-content ">
                                        <h5><i class="fa-solid fa-users-gear"></i> What We Offer?</h5>
                                        <h2>Comprehensive Dental Services at MAPRU</h2>
                                        <p>
                                            At MAPRU, we provide a wide range of dental services designed to support
                                            your oral health and confidence.
                                            From preventive care to advanced treatments, our team is committed to
                                            delivering comfortable, reliable,
                                            and patient-focused solutions for every smile.
                                        </p>
                                        <div class="makeappointment-btn">
                                            <button>Book An Appointment</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- ================================== Section 3 ========================= -->
            <section class="section3">
                <div class="services-category-main-container">
                    
                        <div class="services-category-main-container mb-5">

                            <h5>Our Services</h5>
                            <h2>
                                Services We Offer
                            </h2>

                        </div>
                    <div class="services-category-inner ">
                        <div class="row row-cols-3 g-4 d-flex align-items-center justify-content-center">

                            <div class="col services-col">
                                <div class="services-col-container">
                                    <div class="services-col-container-inner">
                                        <div class="services-col-container-content ">

                                            <h2>Surgical Treatment</h2>
                                            <h5>Intervene</h5>
                                            <p>
                                                Performs precise surgical procedures to address complex dental issues,
                                                ensuring proper function and oral health.
                                            </p>

                                        </div>
                                        <div
                                            class="services-col-container-btn d-flex justify-content-start align-items-center">
                                            <a href="../user-interface/services-more-info.php" class="services-col-btn">
                                                <span class="btn-text">More Info</span>
                                                <i class="fa-solid fa-angle-right"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col services-col">
                                <div class="services-col-container services-col-img ">
                                    <div class="services-col-container-inner">
                                        <img src="../../assets/images/user-interface/banners-images-logo/second banner.jpg"
                                            alt="">
                                    </div>
                                </div>

                            </div>
                            <div class="col services-col">
                                <div class="services-col-container">
                                    <div class="services-col-container-inner">
                                        <div class="services-col-container-content ">

                                            <h2>Cosmetic Dentistry</h2>
                                            <h5>Enhance</h5>
                                            <p>Improves the overall appearance of teeth and smile through
                                                aesthetic-focused
                                                dental treatments.
                                            </p>

                                        </div>
                                        <div
                                            class="services-col-container-btn d-flex justify-content-start align-items-center">
                                            <a href="../user-interface/services-more-info.php" class="services-col-btn">
                                                <span class="btn-text">More Info</span>
                                                <i class="fa-solid fa-angle-right"></i>
                                            </a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="col services-col">
                                <div class="services-col-container">
                                    <div class="services-col-container-inner">
                                        <div class="services-col-container-content ">

                                            <h2>Prosthodontics</h2>
                                            <h5>Restore</h5>
                                            <p>
                                                Replaces or rebuilds missing or damaged teeth using specialized
                                                restorative
                                                procedures.
                                            </p>

                                        </div>
                                        <div
                                            class="services-col-container-btn d-flex justify-content-start align-items-center">
                                            <a href="../user-interface/services-more-info.php" class="services-col-btn">
                                                <span class="btn-text">More Info</span>
                                                <i class="fa-solid fa-angle-right"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col services-col">
                                <div class="services-col-container">
                                    <div class="services-col-container-inner">
                                        <div class="services-col-container-content ">

                                            <h2>Periodontics</h2>
                                            <h5>Protect</h5>
                                            <p>
                                                Focuses on preserving gum and bone health to prevent diseases that can
                                                compromise long-term oral stability.
                                            </p>

                                        </div>
                                        <div
                                            class="services-col-container-btn d-flex justify-content-start align-items-center">
                                            <a href="../user-interface/services-more-info.php" class="services-col-btn">
                                                <span class="btn-text">More Info</span>
                                                <i class="fa-solid fa-angle-right"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col services-col">
                                <div class="services-col-container">
                                    <div class="services-col-container-inner">
                                        <div class="services-col-container-content ">

                                            <h2>Orthodontics</h2>
                                            <h5>Align</h5>
                                            <p>
                                                Corrects tooth alignment and bite issues to achieve a straighter and
                                                healthier smile.
                                            </p>

                                        </div>
                                        <div
                                            class="services-col-container-btn d-flex justify-content-start align-items-center">
                                            <a href="../user-interface/services-more-info.php" class="services-col-btn">
                                                <span class="btn-text">More Info</span>
                                                <i class="fa-solid fa-angle-right"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </section>



            <!-- ============================= Section 4 =================== -->

            <section class="section4">
                <div class="why-choose-mapru-services-main">
                    <div class="why-choose-mapru-services-inner ">
                        <div class="row row-cols-1 row-cols-lg-2">
                            <div class="col">
                                <div class="why-mapru-services-col-left">
                                    <h5><i class="fa-regular fa-lightbulb"></i> Why Choose MAPRU Dental Service?</h5>
                                    <h2>Trusted Dental Care You Can Rely On</h2>
                                    <p>
                                        Choosing the right dental service matters. At MAPRU, every treatment is handled
                                        with precision, care, and attention to your comfort. Our experienced team uses
                                        modern techniques to ensure safe, effective, and personalized dental solutions
                                        — so you can feel confident at every visit.
                                    </p>

                                    <ul>
                                        <li><i class="fa-solid fa-check-double"></i> Experienced dentists focused on
                                            safe, precise treatments</li>
                                        <li><i class="fa-solid fa-check-double"></i> Modern equipment for accurate and
                                            comfortable procedures</li>
                                        <li><i class="fa-solid fa-check-double"></i> Clear explanations so you
                                            understand every step</li>
                                        <li><i class="fa-solid fa-check-double"></i> Patient comfort and long-term oral
                                            health as priorities</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col">
                                <div class="why-mapru-services-col-right">
                                    <div class="dental-images-grid">
                                        <div class="dental-images-grid-left d-flex flex-column">
                                            <div class="dental-images-grid-left-top">
                                                <img src="../../assets/images/user-interface/banners-images-logo/second banner.jpg"
                                                    alt="Dental patient" class="dental-img-1">
                                            </div>
                                            <div class="dental-images-grid-left-bottom">
                                                <img src="../../assets/images/user-interface/banners-images-logo/second banner.jpg"
                                                    alt="Dental professional" class="dental-img-2">
                                            </div>
                                        </div>
                                        <div class="dental-images-grid-right ">
                                            <div class="dental-images-grid-right-inner">
                                                <img src="../../assets/images/user-interface/banners-images-logo/second banner.jpg"
                                                    alt="Dental office" class="dental-img-3">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <!-- =================== Section 5 - FAQ ======================= -->

            <section class="section5">
                <div class="faq-main-container">
                    <div class="faq-main-container-inner">
                        <div class="row row-cols-2">
                            <div class="col col-5">
                                <div class="faq-col-left">
                                    <div class="faq-col-left-inner w-100">
                                        <div class="faq-header">
                                            <h5><i class="fa-regular fa-circle-question ms-1"></i> Frequently Asked
                                                Questions</h5>
                                            <h2>Everything</h2>
                                            <h2 class="mb-4">You Need to Know!</h2>
                                            <p class="faq-description">
                                                Find clear answers to the most common questions about our dental
                                                services, treatments, and patient care. We’re here to help you feel
                                                confident and informed before your visit.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col col-7">
                                <div class="faq-col-right">
                                    <div class="faq-col-right-inner">
                                        <div class="faq-content">
                                            <div class="faq-list">
                                                <div class="faq-item">
                                                    <div class="faq-question">
                                                        <button>How often should I visit the dentist?</button>
                                                        <div class="faq-questionn-icon">
                                                            <i class="fa-solid fa-angle-down"></i>
                                                        </div>
                                                    </div>
                                                    <div class="faq-answer">
                                                        <p>We recommend visiting the dentist at least twice a year for
                                                            check-ups and cleanings.</p>
                                                    </div>
                                                </div>

                                                <div class="faq-item">
                                                    <div class="faq-question">
                                                        <button>What should I do in a dental emergency?</button>
                                                        <div class="faq-questionn-icon">
                                                            <i class="fa-solid fa-angle-down"></i>
                                                        </div>
                                                    </div>
                                                    <div class="faq-answer">
                                                        <p>Contact us immediately. We provide urgent care to address
                                                            pain, broken teeth, or other dental emergencies.</p>
                                                    </div>
                                                </div>

                                                <div class="faq-item">
                                                    <div class="faq-question">
                                                        <button>Do you offer services for kids?</button>
                                                        <div class="faq-questionn-icon">
                                                            <i class="fa-solid fa-angle-down"></i>
                                                        </div>
                                                    </div>
                                                    <div class="faq-answer">
                                                        <p>Yes! We provide child-friendly dental services for kids of
                                                            all ages.</p>
                                                    </div>
                                                </div>

                                                <div class="faq-item">
                                                    <div class="faq-question">
                                                        <button>What are my options for replacing missing
                                                            teeth?</button>
                                                        <div class="faq-questionn-icon">
                                                            <i class="fa-solid fa-angle-down"></i>
                                                        </div>
                                                    </div>
                                                    <div class="faq-answer">
                                                        <p>We offer dental implants, bridges, and dentures depending on
                                                            your needs.</p>
                                                    </div>
                                                </div>

                                                <div class="faq-item">
                                                    <div class="faq-question">
                                                        <button>Is teeth whitening safe?</button>
                                                        <div class="faq-questionn-icon">
                                                            <i class="fa-solid fa-angle-down"></i>
                                                        </div>
                                                    </div>
                                                    <div class="faq-answer">
                                                        <p>Yes, professional teeth whitening under supervision is safe
                                                            and effective.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <!-- =========================== Section 6 ======================================= -->

            <section class="section6">
                <div class="section6-inner d-flex flex-column justify-content-end align-items-center">
                    
                            <div class="col-left-book-now text-center">
                                <h2>
                                    Ready to Book Your Appointment?
                                </h2>
                                <p>
                                    Contact us today to schedule your visit and take the first step toward a healthier smile.
                                </p>
                            </div>
                       
                             <div class="col-right-book-now">
                                <div class="col-right-book-now-btn h-100 ">
                                <button class="book-now-btn">
                                    Book Appointment
                                </button>
                                </div>
                            </div>
                    
                </div>

            </section>



            <!-- =================== Footer ========================= -->

            <?php include '../user-interface/footer.php'; ?>

        </div>





        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="../../assets/js/user-interface/navbar.js"></script>
        <script src="../../assets/js/user-interface/footer.js"></script>
        <script src="../../assets/js/user-interface/services.js"></script>




</body>

</html>