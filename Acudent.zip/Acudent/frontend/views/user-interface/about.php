<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAPRU - About</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../../assets/css/user-interface/services.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/navbarnobg.css">
    <link rel="stylesheet" href="../../assets/css/user-interface/footer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Pacifico&display=swap');
    </style>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap');
    </style>

</head>

<body>

    <div class="main-container overflow-hidden">
                
        <?php include '../user-interface/navbar.php'; ?>
      

        <div class="landing-page-content-main-container">
            <!----------Landing Page --------------->


            <section class="section1 d-flex flex-column justify-content-center align-items-center">

                <div class="dentists-hero-banner w-100 ">
                    <div class="dentists-hero-banner-inner d-flex flex-column justify-content-center align-items-center">
                        <div class="dentists-hero-banner-title">
                            <h1>Know More About Us</h1>
                        </div>
                        <hr class="hori-line">
                          <div class="dentists-hero-banner-sub mt-4 d-flex flex-row w-100 justify-content-center align-items-center gap-3">
                            <div class="dentists-hero-banner-sub-left d-flex flex-row">
                                <h5> <a href="../user-interface/index.php"><i class="fa-solid fa-house me-2"></i>Home</a> <i class="fa-solid fa-chevron-right mx-3"></i></h5>
                                

                            </div>
                            <div class="dentists-hero-banner-sub-right">
                                <h5>About</h5>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <section class="section2">
                
            </section>
            
        <!-- =================== Footer ========================= -->
       
      <?php include '../user-interface/footer.php'; ?>

    </div>





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../../assets/js/user-interface/navbar.js"></script>
    <script src="../../assets/js/user-interface/footer.js"></script>



</body>

</html>