<footer class="footer-main-container">
  <div class="row row-cols-xxl-1 row-cols-xl-1 row-cols-lg-1 row-cols-md-1 row-cols-sm-1 row-cols-1">
    <div class="col-12 ">
      <div class="footer-main-wrapper">
        <div class="footer-title-top">
          <h3>Mapru Dental Clinic</h3>
        </div>
        <div class="footer-text-top">
          <p>Mapru Dental Clinic delivers modern dental solutions with a focus on precision and
            patient care.
            <br> We’re here to keep your smile bright and healthy.
          </p>
        </div>
      </div>
    </div>

    <div class="row  row-cols-xxl-3 row-cols-xl-3 row-cols-lg-2 row-cols-md-1 row-cols-sm-1 row-cols-1 py-3">
      <div class="col-xxl-5 col-xl-5 col-lg-6 col-md-12 col-sm-12 col-12">
        <div class="footer-second-row-container">
          <div class="footer-left-wrapper">
            <div class="footer-left-location-text">
              <h5>Location</h5>
            </div>
            <div class="footer-left">
              <div class="footer-left-icon-wrapper">
                <i class="fa-solid fa-location-dot"></i>
              </div>
              <div class="footer-left-text-wrapper">
                <p>9067 DSM Subdivision Mambog 1, Bacoor City, Cavite</p>
              </div>
            </div>

            <div class="footer-left">
              <div class="footer-left-icon-wrapper">
                <i class="fa-solid fa-calendar-day"></i>
              </div>
              <div class="footer-left-text-wrapper">
                <p>Monday - Sunday</p>
              </div>
            </div>

            <div class="footer-left">
              <div class="footer-left-icon-wrapper">
                <i class="fa-solid fa-clock"></i>
              </div>
              <div class="footer-left-text-wrapper">
                <p>10:00 AM - 5:00 PM</p>
              </div>
            </div>
          </div>


        </div>
      </div>

      <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-12 col-sm-12 col-12">
        <div class="footer-middle-container">
          <div class="footer-middle-wrapper">
            <h5>Navigation</h5>
          </div>

          <div class="footer-middle">
            <div class="footer-middle-icon-wrapper">

            </div>
            <div class="footer-middle-text">
              <p><a href="../user-interface/about.php">About us</a></p>
            </div>
          </div>

          <div class="footer-middle">
            <div class="footer-middle-icon-wrapper">

            </div>
            <div class="footer-middle-text">
              <p><a href="../user-interface/doctors.php">Our Doctors</a></p>
            </div>
          </div>

          <div class="footer-middle">
            <div class="footer-middle-icon-wrapper">

            </div>
            <div class="footer-middle-text">
              <p><a href="../user-interface/services.php">Services</a></p>
            </div>
          </div>

          <div class="footer-middle">
            <div class="footer-middle-icon-wrapper">

            </div>
            <div class="footer-middle-text">
              <p><a href="../user-interface/contact.php">Contact Us</a></p>
            </div>
          </div>
        </div>
      </div>

      <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-12 col-sm-12 col-12">
        <div class="footer-right-container">
          <div class="footer-right-wrapper">
            <h5>Company</h5>
          </div>

          <div class="company-footer">
            <p><a href="#">Privacy Policy</a></p>
            <p><a href="#">Terms & Condition</a></p>

          </div>
        </div>
      </div>
    </div>

    <div class="row row-cols-xxl-3 row-cols-xl-3 row-cols-lg-2 row-cols-md-1 row-cols-sm-1 row-cols-1">
      <div class="col-xxl-5 col-xl-5 col-lg-6 col-md-12 col-sm-12 col-12">
        <div class="footer-lower-bottom-left-container">
          <div class="footer-lower-bottom-left-wrapper">
            <h5>Questions</h5>
          </div>

          <div class="footer-left">
            <div class="footer-left-icon-wrapper">
              <i class="fa-solid fa-phone"></i>
            </div>
            <div class="footer-left-text-wrapper">
              <p>0915 748 5132</p>
            </div>
          </div>


          <div class="footer-left">
            <div class="footer-left-icon-wrapper">
              <i class="fa-solid fa-envelope"></i>
            </div>
            <div class="footer-left-text-wrapper">
              <p><a href="maprudentalclinic@gmail.com">maprudentalclinic@gmail.com</a></p>
            </div>
          </div>

        </div>
      </div>

      <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-12 col-sm-12 col-12 py-4">
        <div class="footer-lower-middle-container">
          <div class="footer-lower-middle-wrapper">
            <h5>Socials</h5>
          </div>

          <div class="footer-lower-middle-socials-main-container">
            <div class="footer-lower-middle-socials-container">
              <div class="footer-lower-middle-socials-wrapper">

                <a href="https://www.instagram.com/maprudentalclinic" target="_blank">
                  <i class="fa-brands fa-instagram"></i>
                </a>

                <a href="https://www.facebook.com/maprudentalclinic" target="_blank">
                  <i class="fa-brands fa-facebook"></i>
                </a>

                <a href="https://www.tiktok.com/@maprudentalclinic" target="_blank">
                  <i class="fa-brands fa-tiktok"></i>
                </a>
              </div>

            </div>
          </div>

        </div>

      </div>

      <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-12 col-sm-12 col-12 py-4 d-flex flex-row">
        <div class="footer-lower-right-container">
          <div class="footer-lower-right-wrapper">
            <h5>Accepted Payment Method</h5>
          </div>

          <div class="footer-lower-right-payment-container">
            <div class="accepted-card-payment-footer d-flex flex-row gap-2">

              <div class="payment-item">
                <i class="fa-brands fa-cc-visa"></i>
                <p>Visa</p>
              </div>

              <div class="payment-item">
                <i class="fa-brands fa-cc-mastercard"></i>
                <p>Mastercard</p>
              </div>


              <div class="payment-item">
                <i class="fa-solid fa-wallet"></i>
                <p>E-Wallet</p>
              </div>

              <div class="payment-item">
                <i class="fa-solid fa-peso-sign"></i>
                <p>Cash</p>
              </div>

            </div>
          </div>

          <div class="footer-lower-right-note py-3">
            <p>Note: You can only pay at the clinic.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <hr>

  <div class="copy-right-mapru">
    <p>Mapru Dental Clinic</p>
  </div>
  <div class="copyright">
    <p>&copy; All Rights Reserved</p>
  </div>

</footer>