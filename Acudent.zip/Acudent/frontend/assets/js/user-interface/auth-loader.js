let authLoaded = false; // Prevent double loading

function loadAuthModal() {
  if (authLoaded) {
    // Already loaded → Just open modal
    document.getElementById('authentication-modal-container-id').style.display = 'flex';
    document.body.classList.add('modal-open');
    return;
  }

  fetch("/frontend/views/user-interface/auth.html")
    .then(res => res.text())
    .then(html => {
      document.getElementById("authentication-modal-container").innerHTML = html;
      
      // Load auth.js only AFTER HTML is injected
      const script = document.createElement("script");
      script.src = "/frontend/assets/js/user-interface/auth.js";

      script.onload = () => {
        authLoaded = true;
        if (typeof initAuthModal === "function") {
          initAuthModal(); // Initialize modal events
        }

        // Open modal immediately after loading
        document.getElementById('authentication-modal-container-id').style.display = 'flex';
        document.body.classList.add('modal-open');
      };

      document.body.appendChild(script);
    })
    .catch(err => console.error("Failed to load auth modal:", err));
}

// Attach click event to the Sign In button
document.addEventListener("DOMContentLoaded", () => {
  const signInBtn = document.querySelector('.btn-signin');
  signInBtn?.addEventListener('click', (e) => {
    e.preventDefault();
    loadAuthModal();
  });
});
