function initAuthModal() {
  const modal = document.getElementById('authentication-modal-container-id');
  if (!modal) return; // Modal not found, stop execution

  const container = document.getElementById('container');
  const adminContainer = document.getElementById('adminContainer');

  const openModalBtn = document.querySelector('.btn-signin');
  const closeModalBtn = document.getElementById('closeModal');

  const registerBtn = document.getElementById('signupBtn');
  const loginBtn = document.getElementById('signinBtn');
  const adminBtn = document.getElementById('adminLoginBtn');

  // ✅ Open Modal
  openModalBtn?.addEventListener('click', (e) => {
    e.preventDefault();
    showModal();
  });

  // ✅ Close Modal
  closeModalBtn?.addEventListener('click', closeModal);

  // ✅ Background Close
  window.addEventListener('click', (event) => {
    if (event.target === modal) {
      closeModal();
    }
  });

  // ✅ Toggle to Sign Up
  registerBtn?.addEventListener('click', () => {
    container.classList.add('active');
    adminContainer.classList.remove('active');
  });

  // ✅ Toggle to Sign In
  loginBtn?.addEventListener('click', () => {
    container.classList.remove('active');
    adminContainer.classList.remove('active');
  });

  // ✅ Toggle to Admin Login
  adminBtn?.addEventListener('click', () => {
    adminContainer.classList.add('active');
    container.classList.remove('active');
  });

  // ✅ Admin Back Button (Must be global for HTML inline onclick)
  window.goBack = function () {
    adminContainer.classList.remove('active');
  };

  // ✅ URL-Based Auto-Show Logic
  const urlParams = window.location.search;
  if (urlParams.includes('auth=failed') || urlParams.includes('error')) {
    showModal();
  }

  if (urlParams.includes('registered=1')) {
    showModal();
    container.classList.remove('active'); // Show Login
  }

  if (urlParams.includes('signup=error')) {
    showModal();
    container.classList.add('active'); // Show Sign Up
  }

  // ===== Functions =====
  function showModal() {
    modal.style.display = 'flex';
    document.body.classList.add('modal-open');
  }

  function closeModal() {
    modal.style.display = 'none';
    container.classList.remove('active');
    adminContainer.classList.remove('active');
    document.body.classList.remove('modal-open');
  }
}
