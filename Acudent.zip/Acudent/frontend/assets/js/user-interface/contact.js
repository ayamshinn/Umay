document.addEventListener("DOMContentLoaded", () => {

  encouragementtext();
  section2Animation();
  section3Animation();
  section4Animation();
  section5Animation();
    section6Animation();
        section75Animation();




});





function section2Animation() {
  const section = document.querySelector('.section2');
  const reveals = section.querySelectorAll('.reveal');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.1;

      if (el.classList.contains('reveal-left')) requiredRatio = 0.1;
      if (el.classList.contains('reveal-right')) requiredRatio = 0.1;



      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.1, .1]
  });

  reveals.forEach(el => observer.observe(el));
}




function section3Animation() {
  const section = document.querySelector('.section7');
  const reveals = section.querySelectorAll('.reveal');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-left')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-right')) requiredRatio = 0.2;


      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, 0.2]
  });

  reveals.forEach(el => observer.observe(el));
}


function section4Animation() {
  const section = document.querySelector('.section4');
  const reveals = section.querySelectorAll('.reveal');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-left')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-right')) requiredRatio = 0.2;


      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, 0.2]
  });

  reveals.forEach(el => observer.observe(el));
}

function section5Animation() {
  const section = document.querySelector('.section5');
  const reveals = section.querySelectorAll('.reveal');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.1;
      if (el.classList.contains('reveal-header')) requiredRatio = 0.1;


      if (el.classList.contains('reveal-left')) requiredRatio = 0.3;
      if (el.classList.contains('reveal-right')) requiredRatio = 0.3;


      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.1, 0.3, 0.3]
  });

  reveals.forEach(el => observer.observe(el));
}



function section6Animation() {
  const section = document.querySelector('.section6');
  const reveals = section.querySelectorAll('.reveal');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-left')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-right')) requiredRatio = 0.2;


      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, 0.2]
  });

  reveals.forEach(el => observer.observe(el));
}



function section75Animation() {
  const section = document.querySelector('.section75');
  const reveals = section.querySelectorAll('.reveal');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-header')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-content')) requiredRatio = 0.1;


      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, 0.2]
  });

  reveals.forEach(el => observer.observe(el));
}





// ================= REVIEWS FOR CONTACT SECTION ========================

function encouragementtext() {
  const reviews = [
    {
      text: "I was very nervous before my visit, but the staff made me feel comfortable and cared for. Everything was explained clearly.",
      author: "— Patient A"
    },
    {
      text: "MAPRU Dental Clinic has such a calm environment. The dentists are gentle and truly listen to your concerns.",
      author: "— Patient B"
    },
    {
      text: "From the moment I reached out, I felt supported. They made my dental visit stress-free and reassuring.",
      author: "— Patient C"
    }
  ];

  const wrapper1 = document.getElementById("contact-us-reviews-wrapper-id");
  let currentIndex1 = 0;

  reviews.forEach((review, index) => {
    const slide = document.createElement("div");
    slide.className = "review-slide" + (index === 0 ? " active" : "");
    slide.innerHTML = `
        <p class="review-text">“${review.text}”</p>
        <div class="review-author">${review.author}</div>
    `;
    wrapper1.appendChild(slide);
  });

  const slides = document.querySelectorAll(".review-slide");

  function showNextSlide() {
    slides[currentIndex1].classList.remove("active");
    currentIndex1 = (currentIndex1 + 1) % slides.length;
    slides[currentIndex1].classList.add("active");
  }

  setInterval(showNextSlide, 5000);

}