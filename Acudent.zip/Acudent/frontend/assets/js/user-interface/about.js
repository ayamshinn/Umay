// Add this JavaScript to your page (e.g., in about.js or before </body>)
document.addEventListener('DOMContentLoaded', function () {
  const section2 = document.querySelector('.section2');
  const imgCol1 = document.querySelector('.img-col-1');
  const imgCol2 = document.querySelector('.img-col-2');
  const imgCol3 = document.querySelector('.img-col-3');
  const imgCol4 = document.querySelector('.img-col-4');

  // Initial offset values (in pixels) - starts scattered
  const initialOffsets = {
    col1: -20, // left
    col2: -20, // top
    col3: -20, // bottom
    col4: -20  // right
  };



  // Easing function for smoother animation (ease-out cubic)
  const easeOutCubic = (x) => 1 - Math.pow(1 - x, 3);

  function handleScroll() {
    if (!section2 || !imgCol1 || !imgCol2 || !imgCol3 || !imgCol4) {
      console.error('One or more elements not found in section2');
      return;
    }

    const rect = section2.getBoundingClientRect();
    const windowHeight = window.innerHeight;
    const sectionHeight = rect.height;
    const sectionTop = rect.top;
    const sectionBottom = rect.bottom;

    let progress = 0;

    // Animation only starts when section2 is entering or in the viewport
    if (sectionTop < windowHeight && sectionBottom > 0) {
      // Calculate progress based on how much the section has scrolled into view
      // Starts at 0 (scattered) when section top reaches viewport bottom
      // Reaches 1 (fixed) when section center is at viewport center
      const startPoint = windowHeight; // When sectionTop = windowHeight, progress = 0
      const endPoint = windowHeight / 2; // When sectionTop = windowHeight/2, progress = 1
      const currentPosition = sectionTop;

      if (currentPosition >= startPoint) {
        progress = 0; // Fully scattered
      } else if (currentPosition <= endPoint) {
        progress = 1; // Fully fixed
      } else {
        progress = 1 - ((currentPosition - endPoint) / (startPoint - endPoint));
        progress = Math.max(0, Math.min(1, progress));
      }
    } else if (sectionBottom <= 0) {
      // Section has scrolled past - keep fixed
      progress = 1;
    }
    // If section is below viewport, stays scattered (progress = 0)

    // Apply easing
    const easedProgress = easeOutCubic(progress);

    // Calculate current offsets: starts at -20px (scattered), goes to 0px (fixed)
    const currentOffsets = {
      col1: initialOffsets.col1 * (1 - easedProgress),
      col2: initialOffsets.col2 * (1 - easedProgress),
      col3: initialOffsets.col3 * (1 - easedProgress),
      col4: initialOffsets.col4 * (1 - easedProgress)
    };

    // Apply transformations
    imgCol1.style.left = `${currentOffsets.col1}px`;
    imgCol2.style.top = `${currentOffsets.col2}px`;
    imgCol3.style.bottom = `${currentOffsets.col3}px`;
    imgCol4.style.right = `${currentOffsets.col4}px`;
  }

  // Throttled scroll event listener
  let ticking = false;
  window.addEventListener('scroll', function () {
    if (!ticking) {
      window.requestAnimationFrame(function () {
        handleScroll();
        ticking = false;
      });
      ticking = true;
    }
  });

  // Initial call on load
  handleScroll();
  section2Animation();
  section3Animation();
  section4Animation();
  section5Animation();
  section6Animation();


    section7Animation();




});


function section2Animation() {
  const section = document.querySelector('.section2');
  const reveals = section.querySelectorAll('.reveal');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-header')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-content')) requiredRatio = 0.3;


      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, 0.3]
  });

  reveals.forEach(el => observer.observe(el));
}



function section3Animation() {
  const section = document.querySelector('.section3');
  const reveals = section.querySelectorAll('.reveal');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-header')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-content')) requiredRatio = 0.3;


      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, 0.3]
  });

  reveals.forEach(el => observer.observe(el));
}


function section4Animation() {
  const section = document.querySelector('.section4');
  const reveals = section.querySelectorAll('.reveal');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-header')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-content')) requiredRatio = 0.3;


      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, 0.2, .3]
  });

  reveals.forEach(el => observer.observe(el));
}




function section5Animation() {
  const section = document.querySelector('.section5');
  const reveals = section.querySelectorAll('.reveal');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-left')) requiredRatio = 0.2;

      if (el.classList.contains('reveal-header')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-content')) requiredRatio = 0.3;


      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, 0.2, .3]
  });

  reveals.forEach(el => observer.observe(el));
}




function section6Animation() {
  const section = document.querySelector('.section6');
  const reveals = section.querySelectorAll('.reveal');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;


      if (el.classList.contains('reveal-header')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-content')) requiredRatio = 0.4;


      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, .4]
  });

  reveals.forEach(el => observer.observe(el));
}




function section7Animation() {
  const section = document.querySelector('.section7');
  const reveals = section.querySelectorAll('.reveal');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;


      if (el.classList.contains('reveal-header')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-content')) requiredRatio = 0.4;


      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, .4]
  });

  reveals.forEach(el => observer.observe(el));
}
