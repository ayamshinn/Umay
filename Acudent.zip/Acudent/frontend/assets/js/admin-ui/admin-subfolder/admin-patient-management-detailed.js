// ===================== SAMPLE DATA (Defined Globally for Reusability) =====================
const sampleDentalHistoryData = [
    {
        id: 1,  // Unique ID for identification (add this to each row)
        date: "2023-10-15",
        services: "Cleaning",
        patientName: "Dracy Malibu",
        patientId: "P-1005",
        status: "Completed",
        action: '<button class="view-btn" data-id="1">View</button>'  // Add data-id matching the row's id
    },
    {
        id: 2,
        date: "2023-11-02",
        services: "Filling",
        patientName: "Jane Smith",
        patientId: "P-1006",
        status: "Upcoming",
        action: '<button class="view-btn" data-id="2">View</button>'
    },
    // Add more rows as needed (ensure each has a unique id and matching data-id)
];

// ===================== POPULATE TABLE FUNCTION (Updated to Attach Listeners) =====================
function populateTable(data) {
    const tbody = document.getElementById('patient-dental-history-tb-body');
    if (!tbody) {
        console.error('Table body not found!');
        return;
    }
    tbody.innerHTML = ''; // Clear existing rows
    data.forEach(row => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${row.date}</td>
            <td>${row.services}</td>
            <td>${row.patientName}</td>
            <td>${row.patientId}</td>
            <td>${row.status}</td>
            <td>${row.action}</td>
        `;
        tbody.appendChild(tr);
    });
    // ===================== ATTACH EVENT LISTENERS TO VIEW BUTTONS =====================
    // After populating, find all view buttons and add click handlers
    const viewButtons = tbody.querySelectorAll('.view-btn');
    viewButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            const rowId = e.target.getAttribute('data-id');  // Get the ID from the button
            const rowData = data.find(row => row.id == rowId);  // Find the matching data
            if (rowData) {
                openDentalHistoryModal(rowData);  // Call a function to open the modal with data
            }
        });
    });
}




// ===================== MODAL FUNCTION (Updated for Opening and Populating) =====================
function DentalHistoryModal() {
    const modal = document.querySelector('.dental-history-modal-container');
    const closeModalBtns = document.querySelectorAll('.dental-history-modal-close-button');
    // Function to open the modal with specific data
    window.openDentalHistoryModal = function(rowData) {
        // Populate the modal with row data (customize based on your modal's HTML)
        const remarksElement = modal.querySelector('#remarks-of-patient');  // Update remarks
        const notesElement = modal.querySelector('#notes-of-patient');    // Update notes
        if (remarksElement) {
            remarksElement.innerHTML = ` `;
        }
        if (notesElement) {
            notesElement.textContent = ``;  // 
        }
        modal.classList.add('active');
    };
    closeModalBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            modal.classList.remove('active');  // Use classList for consistency
        });
    });
    // Optional: Close on outside click
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('active');
        }
    });
}

function buttons() {
    // ===================== BACK TO DENTIST LIST =====================
    const viewButtons = document.querySelectorAll('.back-btn');
    viewButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const url = btn.getAttribute('data-page');
            if (!url) return;

            // Remove the param logic since dentistId is not needed
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
            }
        });
    });

    const viewmoreButtons = document.querySelectorAll('.patient-view-more-btn');
    viewmoreButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const url = btn.getAttribute('data-page');
            if (!url) return;

            // Remove the param logic since dentistId is not needed
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
            }
        });
    });
}





function initAdminPatientManagementDetailed() {
    const page = document.querySelector('#admin-patient-detail-view-page-id');
  if (!page) return;
    console.log('Patient Management Detailed initialized ✅');

    // ===================== READ PATIENT ID FROM URL ===================== //
    const params = new URLSearchParams(window.location.search);
    const patientId = params.get('id');

    if (patientId) {
        console.log(`Loading data for patient: ${patientId}`);

        // Example: show the ID in the detailed header
        const idElement = document.querySelector('.patient-id-display');
        if (idElement) idElement.textContent = `Patient ID: ${patientId}`   ;

        // TODO: Replace with fetch() or data lookup if you connect to backend
        // e.g., fetch(`/api/patients/${patientId}`).then(...)
    }

    // ===================== INITIALIZE MODAL =====================
    DentalHistoryModal();  // Call this to set up the modal and define openDentalHistoryModal

    // ===================== POPULATE TABLE WITH SAMPLE DATA =====================
    // This runs every time the page loads, so the data will be visible when you navigate back
    populateTable(sampleDentalHistoryData);
    buttons();

    
}

document.addEventListener('DOMContentLoaded', initAdminPatientManagementDetailed);
