function initAdminAppointments() {
    initCalendar();
}
function initCalendar() {
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August',
        'September', 'October', 'November', 'December'];
    let currentDate = new Date();
    const today = new Date();
    let datePickingMode = false;
    let selectedDate = null;
    let appointmentMode = null;  // Track whether we're in 'add' or 'edit' mode
    
    let currentYear = currentDate.getFullYear();
    let currentMonth = String(currentDate.getMonth() + 1).padStart(2, '0');
    const appointments = [];
    
    function renderDentistCalendar() {
        let year = currentDate.getFullYear();
        let month = currentDate.getMonth();
        // Update the month display in the new HTML
        document.getElementById('months-display').innerText = months[month] + ' ' + year;
    
        let firstDayOfWeek = new Date(year, month, 1).getDay();  // 0 = Sunday
        let daysInMonth = new Date(year, month + 1, 0).getDate();
        let daysInPrevMonth = new Date(year, month, 0).getDate();
    
        let daysContainer = document.querySelector('.calendar-days-number-container');
        daysContainer.innerHTML = '';  // Clear existing static content
    
        let nextDayCounter = 1;
    
        // Generate 42 cells (6 weeks x 7 days) for a full grid
        for (let cellIndex = 0; cellIndex < 42; cellIndex++) {
            let dayDiv = document.createElement('div');
            dayDiv.className = 'calendar-days-number';
    
            if (cellIndex < firstDayOfWeek) {
                // Previous month's days
                let prevDay = daysInPrevMonth - (firstDayOfWeek - 1 - cellIndex);
                dayDiv.innerHTML = `${prevDay}<br><small>Prev month</small>`;
                dayDiv.classList.add('prev-month');
            } else if (cellIndex < firstDayOfWeek + daysInMonth) {
                // Current month's days
                let day = cellIndex - firstDayOfWeek + 1;
                dayDiv.dataset.day = day;
                dayDiv.innerHTML = `${day}<br>`;

                const dayDateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                const dayAppointments = appointments.filter(app => app.date === dayDateStr);
                
                if (dayAppointments.length > 0) {
                    dayAppointments.forEach(app => {
                        const appDiv = document.createElement('div');
                        appDiv.className = 'calendar-appointment-item';
                        appDiv.innerHTML = `<small>${app.patient} - ${app.time} (${app.service})</small>`;
                        dayDiv.appendChild(appDiv);
                    });
                } else {
                    const noAppDiv = document.createElement('div');
                    noAppDiv.className = 'no-appointments';
                    noAppDiv.innerHTML = '<small>No appointments</small>';
                    dayDiv.appendChild(noAppDiv);
                }
                
                dayDiv.classList.add('current-month');
                
                // Highlight today
                if (day === today.getDate() && month === today.getMonth() && year === today.getFullYear()) {
                    dayDiv.classList.add('today');
                }
    
                // Click handler for current month days
                dayDiv.addEventListener('click', () => {
                    console.log('Calendar clicked, datePickingMode:', datePickingMode, 'appointmentMode:', appointmentMode, 'appointments:', dayAppointments.length); // Debug
                    if (datePickingMode) {
                        selectedDate = new Date(year, month, day);
                        if (appointmentMode === 'add') {
                            openDentistAppointmentModal(selectedDate);
                        } else if (appointmentMode === 'edit') {
                            openDentistEditModal(selectedDate);
                        }
                        datePickingMode = false;  // Reset after use
                        appointmentMode = null;   // Reset mode
                    } else {
                        if (dayAppointments.length > 0) {
                            openDentistViewModal(new Date(year, month, day), dayAppointments);
                        }
                    }
                });
            } else {
                // Next month's days
                dayDiv.innerHTML = `${nextDayCounter}<br><small>Next month</small>`;
                dayDiv.classList.add('next-month');
                nextDayCounter++;
            }
    
            daysContainer.appendChild(dayDiv);
        }
    }
    
    function Dentistprevmonth() {
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderDentistCalendar();
    }
    
    function Dentistnextmonth() {
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderDentistCalendar();
    }
    
    // Handler for "Today" button (resets to current date)
    function goToToday() {
        currentDate = new Date();
        renderDentistCalendar();
    }
    
    // Attach event listeners to buttons (using new IDs)
    document.getElementById('prev-month-btn-id').addEventListener('click', Dentistprevmonth);
    document.getElementById('next-month-btn-id').addEventListener('click', Dentistnextmonth);
    document.querySelector('.todays-date-btn').addEventListener('click', goToToday);
    
    // Initial render
    renderDentistCalendar();
}

document.addEventListener("DOMContentLoaded", initAdminAppointments)


