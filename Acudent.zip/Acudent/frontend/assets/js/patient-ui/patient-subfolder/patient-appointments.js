// Simplified calendar initialization - only renders the calendar grid with navigation
function initPatientAppointments() {
    console.log('Initializing basic calendar...');

    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    let currentDate = new Date();  // Start with current date

    // Office hours: 8:00 AM to 5:00 PM
    const OFFICE_START = '08:00';
    const OFFICE_END = '17:00';
    const SLOT_DURATION = 45; // Minutes per slot (adjust as needed)

    // Function to generate all possible time slots within office hours
    function generateTimeSlots() {
        const slots = [];
        const start = 9; // 9:00 AM
        const end = 17; // 5:00 PM
        for (let hour = start; hour < end; hour++) {
            if (hour === 12) continue;
            slots.push(`${hour.toString().padStart(2, '0')}:00`);
            slots.push(`${hour.toString().padStart(2, '0')}:45`);
        }
        return slots;
    }

    async function fetchBookedTimes(date) {
        // Simulated booked data: now returns an object with time as key and booked count (0-4) as value
        // Up to 4 appointments per slot (one per dentist)
        const mockData = {
            "2025-11-08": { "09:00": 2, "10:30": 4, "11:00": 1 },  // e.g., 2 booked at 9:00, 4 at 10:30 (full), 1 at 11:00
            "2025-11-09": { "13:00": 3, "14:30": 4 },  // 3 at 13:00, 4 at 14:30 (full)
        };
        return mockData[date] || {};  // Return empty object if no data for the date
    }

    // Function to populate the time select with available slots
    async function populateTimeSelect(date) {
        const optionsContainer = document.getElementById('time-options');
        const display = document.getElementById('time-display');
        const hiddenInput = document.getElementById('selected-time');
        if (!optionsContainer) return;
        optionsContainer.innerHTML = '';  // Clear previous options
        const allSlots = generateTimeSlots();
        const bookedCounts = await fetchBookedTimes(date);  // Object like { "09:00": 2 }
        allSlots.forEach(slot => {
            const optionDiv = document.createElement('div');
            const bookedCount = bookedCounts[slot] || 0;
            optionDiv.textContent = `${slot} (${bookedCount}/4 booked)`;
            optionDiv.dataset.value = slot;
            if (bookedCount >= 4) {
                optionDiv.classList.add('disabled');
            } else {
                optionDiv.addEventListener('click', () => {
                    // Update display and hidden input
                    display.textContent = optionDiv.textContent;
                    hiddenInput.value = slot;
                    // Close the dropdown
                    document.getElementById('appointment-time-select').classList.remove('open');
                    optionsContainer.style.display = 'none';
                });
            }
            optionsContainer.appendChild(optionDiv);
        });
        // Reset display if no date selected
        if (!date) {
            display.textContent = 'Select Time';
            hiddenInput.value = '';
        }
    }

    document.getElementById('appointment-date').addEventListener('change', (e) => {
        const selectedDate = e.target.value;
        populateTimeSelect(selectedDate);
    });

    document.getElementById('time-trigger').addEventListener('click', () => {
        const select = document.getElementById('appointment-time-select');
        const options = document.getElementById('time-options');
        const isOpen = select.classList.contains('open');
        if (isOpen) {
            select.classList.remove('open');
            options.style.display = 'none';
        } else {
            select.classList.add('open');
            options.style.display = 'block';
        }
    });
    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
        const select = document.getElementById('appointment-time-select');
        if (!select.contains(e.target)) {
            select.classList.remove('open');
            document.getElementById('time-options').style.display = 'none';
        }
    });

    // Function to populate the custom service select (static options)
    function populateServiceSelect() {
        const optionsContainer = document.getElementById('service-options');
        const display = document.getElementById('service-display');
        const hiddenInput = document.getElementById('selected-service');

        if (!optionsContainer) return;

        // Clear and populate with static options
        optionsContainer.innerHTML = '';
        const services = [
            { value: 'Cleaning', text: 'Cleaning' },
            { value: 'Filling', text: 'Filling' },
            { value: 'Checkup', text: 'Checkup' },
            // Add more as needed
        ];

        services.forEach(service => {
            const optionDiv = document.createElement('div');
            optionDiv.textContent = service.text;
            optionDiv.dataset.value = service.value;

            optionDiv.addEventListener('click', () => {
                // Update display and hidden input
                display.textContent = service.text;
                hiddenInput.value = service.value;
                // Close the dropdown
                document.getElementById('appointment-service-select').classList.remove('open');
                optionsContainer.style.display = 'none';
            });

            optionsContainer.appendChild(optionDiv);
        });
    }

    // Call this once on page load to populate
    populateServiceSelect();

    // Toggle dropdown on trigger click
    document.getElementById('service-trigger').addEventListener('click', () => {
        const select = document.getElementById('appointment-service-select');
        const options = document.getElementById('service-options');
        const isOpen = select.classList.contains('open');

        if (isOpen) {
            select.classList.remove('open');
            options.style.display = 'none';
        } else {
            select.classList.add('open');
            options.style.display = 'block';
        }
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
        const select = document.getElementById('appointment-service-select');
        if (!select.contains(e.target)) {
            select.classList.remove('open');
            document.getElementById('service-options').style.display = 'none';
        }
    });


    // Function to populate the custom payment select (static options)
    function populatePaymentSelect() {
        const optionsContainer = document.getElementById('payment-options');
        const display = document.getElementById('payment-display');
        const hiddenInput = document.getElementById('selected-payment');

        if (!optionsContainer) return;

        // Clear and populate with static options
        optionsContainer.innerHTML = '';
        const payments = [
            { value: 'Cash', text: 'Cash' },
            { value: 'GCash', text: 'GCash' },
            { value: 'Credit Card', text: 'Credit Card' },
            // Add more as needed
        ];

        payments.forEach(payment => {
            const optionDiv = document.createElement('div');
            optionDiv.textContent = payment.text;
            optionDiv.dataset.value = payment.value;

            optionDiv.addEventListener('click', () => {
                // Update display and hidden input
                display.textContent = payment.text;
                hiddenInput.value = payment.value;
                // Close the dropdown
                document.getElementById('appointment-payment-select').classList.remove('open');
                optionsContainer.style.display = 'none';
            });

            optionsContainer.appendChild(optionDiv);
        });
    }

    // Call this once on page load to populate
    populatePaymentSelect();

    // Toggle dropdown on trigger click
    document.getElementById('payment-trigger').addEventListener('click', () => {
        const select = document.getElementById('appointment-payment-select');
        const options = document.getElementById('payment-options');
        const isOpen = select.classList.contains('open');

        if (isOpen) {
            select.classList.remove('open');
            options.style.display = 'none';
        } else {
            select.classList.add('open');
            options.style.display = 'block';
        }
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
        const select = document.getElementById('appointment-payment-select');
        if (!select.contains(e.target)) {
            select.classList.remove('open');
            document.getElementById('payment-options').style.display = 'none';
        }
    });





    // Function to render the calendar grid
    function renderPatientCalendar() {
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();

        // Update month/year header
        const monthYearEl = document.getElementById('patient-month-year');
        if (monthYearEl) {
            monthYearEl.textContent = `${months[month]} ${year}`;
        } else {
            console.error('Month/year element not found');
            return;
        }

        // Calculate calendar grid
        const firstDayOfWeek = new Date(year, month, 1).getDay();  // 0 = Sun, 6 = Sat
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const daysInPrevMonth = new Date(year, month, 0).getDate();
        const totalSlots = firstDayOfWeek + daysInMonth;
        const numRows = Math.ceil(totalSlots / 7);

        // Get container for days
        const daysContainer = document.querySelector('.patient-number-of-days');
        if (!daysContainer) {
            console.error('Days container not found');
            return;
        }
        daysContainer.innerHTML = '';  // Clear previous content

        let dayCounter = 1;  // For current month days
        let prevDayCounter = daysInPrevMonth - firstDayOfWeek + 1;  // For prev month
        let nextDayCounter = 1;  // For next month

        // Build the grid (rows and columns)
        for (let row = 0; row < numRows; row++) {
            const rowDiv = document.createElement('div');
            rowDiv.className = 'row row-cols-7 g-0';

            for (let col = 0; col < 7; col++) {
                const colDiv = document.createElement('div');
                colDiv.className = 'col';

                const box = document.createElement('div');
                box.className = 'patient-shared-calendar-box';

                const cellIndex = row * 7 + col;

                if (cellIndex < firstDayOfWeek) {
                    // Previous month days
                    box.innerHTML = `<strong>${prevDayCounter}</strong>`;
                    box.classList.add('patient-prev-month');
                    prevDayCounter++;
                } else if (dayCounter <= daysInMonth) {
                    // Current month days
                    box.innerHTML = `<strong>${dayCounter}</strong>`;
                    box.classList.add('current-month');

                    // Highlight today's date
                    const today = new Date();
                    if (dayCounter === today.getDate() && month === today.getMonth() && year === today.getFullYear()) {
                        box.classList.add('today');
                    }

                    dayCounter++;
                } else {
                    // Next month days
                    box.innerHTML = `<strong>${nextDayCounter}</strong>`;
                    box.classList.add('patient-next-month');
                    nextDayCounter++;
                }

                colDiv.appendChild(box);
                rowDiv.appendChild(colDiv);
            }

            daysContainer.appendChild(rowDiv);
        }

        console.log('Calendar rendered for', months[month], year);
    }

    // Navigation functions (for prev/next buttons in HTML)
    function Patientprevmonth() {
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderPatientCalendar();
        attachDayClickEvents(); // Re-attach events after re-render
    }

    function Patientnextmonth() {
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderPatientCalendar();
        attachDayClickEvents(); // Re-attach events after re-render
    }

    // Expose globally for HTML onclick
    window.Patientprevmonth = Patientprevmonth;
    window.Patientnextmonth = Patientnextmonth;

    // Initial render
    renderPatientCalendar();

    function attachDayClickEvents() {
        const dayBoxes = document.querySelectorAll('.patient-shared-calendar-box.current-month');
        dayBoxes.forEach(box => {
            box.addEventListener('click', async () => { // Make async to handle populateTimeSelect
                const selectedDay = parseInt(box.textContent.trim());
                const month = currentDate.getMonth();
                const year = currentDate.getFullYear();

                const selectedDate = new Date(year, month, selectedDay);
                const today = new Date();
                const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());

                if (selectedDate < todayStart) {
                    Toast('Cannot book appointments on past dates.');
                    return; // Do not proceed
                }

                // Format selected date (YYYY-MM-DD)
                const formattedDate = `${year}-${String(month + 1).padStart(2, '0')}-${String(selectedDay).padStart(2, '0')}`;

                // Insert into input field
                const dateInput = document.getElementById('selected-date');
                if (dateInput) {
                    dateInput.value = formattedDate;
                }

                // Populate time select with available slots for this date
                await populateTimeSelect(formattedDate);

                // Show modal
                const modal = document.getElementById('book-appointment-container-modal-id');
                if (modal) {
                    modal.style.display = 'flex'; // or 'block' depending on your CSS
                }

                console.log('Selected date:', formattedDate);
            });
        });
    }
    attachDayClickEvents();

    // Close modal when clicking the "X" or Cancel button
    document.querySelectorAll('.shared-appointment-close-modal-btn, .cancel-appointment-btn').forEach(button => {
        button.addEventListener('click', () => {
            const modal = document.getElementById('book-appointment-container-modal-id');
            if (modal) {
                modal.style.display = 'none';
            }
        });
    });

    window.addEventListener('click', (e) => {
        const modal = document.getElementById('book-appointment-container-modal-id');
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });

    //SAMPLE DATA SA APPOINTMENT
    const bookanAppointmentBtn = document.querySelector('.book-an-appointment-btn');
    const modalContainer = document.getElementById('your-appointment-details-modal-container-id');
    const appointmentDetailsCloseBtn = document.querySelectorAll('.your-appointment-details-close-button');
    const appointmentDetailsConfirm = document.querySelector('.your-appointment-details-confirm-button');
    const modal = document.getElementById('book-appointment-container-modal-id');

    // BOOK BUTTON
    if (bookanAppointmentBtn) {
    bookanAppointmentBtn.addEventListener('click', async () => { // Make async for fetchBookedTimes
        const selectedDate = document.getElementById('selected-date').value;
        const appointmentTime = document.getElementById('selected-time').value;
        const appointmentType = document.getElementById('selected-service').value;
        const estimatedFee = document.querySelector('input[name="estimatedFee"]').value;
        const modeOfPayment = document.getElementById('selected-payment').value;
        // Fixed: Check if ANY field is empty (all are required)
        if (!selectedDate || !appointmentTime || !appointmentType || !modeOfPayment) {
            Toast('Please fill in all required fields (Date, Time, Appointment Type, and Mode of Payment).');
            return;
        }

            // Double-check availability (fixed to use object format from fetchBookedTimes)
            const bookedCounts = await fetchBookedTimes(selectedDate);  // Now an object like { "09:00": 2 }
            const bookedCount = bookedCounts[appointmentTime] || 0;  // Get count for the selected time
            if (bookedCount >= 4) {  // Full if 4 or more (one per dentist)
                Toast('This time slot is no longer available. Please select another.');
                // Re-populate the select to reflect current availability
                await populateTimeSelect(selectedDate);
                return;
            }


            document.getElementById('appointment-date').textContent = selectedDate;
            document.getElementById('appointment-time').textContent = appointmentTime;
            document.getElementById('appointment-type').textContent = appointmentType;
            document.getElementById('appointment-payment').textContent = modeOfPayment;

            modalContainer.classList.add('active');  // This should show the modal

            // Debug: Confirm class was added
            console.log('Modal container classes:', modalContainer.classList);
        });
    }

    // ✅ TOAST FUNCTION
    function Toast(message) {
        const toast = document.getElementById('toast-appointment');
        toast.textContent = message;
        toast.classList.add('show');

        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }

    // ✅ CLOSE BUTTON LOGIC
    appointmentDetailsCloseBtn.forEach(button => {
        button.addEventListener('click', () => {
            modalContainer.classList.remove('active');
        });
    });

    // ✅ CONFIRM BUTTON LOGIC (moved outside the close event)
    if (appointmentDetailsConfirm) {
        appointmentDetailsConfirm.addEventListener('click', async () => { // Make async for booking API
            const selectedDate = document.getElementById('selected-date').value;
            // Fixed: Correct selectors for hidden inputs
            const appointmentTime = document.getElementById('selected-time').value;  // Changed from querySelector('selected-time')
            const appointmentType = document.getElementById('selected-service').value
            const modeOfPayment = document.getElementById('selected-payment').value;


            try {
                console.log('Mock booking sent:', { selectedDate, appointmentTime, appointmentType, modeOfPayment });
                Toast('Appointment successfully booked!');
                setTimeout(() => {
                    modalContainer.classList.remove('active');
                    modal.style.display = 'none';
                }, 1000);
            } catch (error) {
                console.error('Booking error:', error);
                Toast('An error occurred. Please try again.');
            }

        });
    }


    const timeSelect = document.getElementById('appointment-time-select');

    // On focus (when user clicks the select), make it a scrollable listbox
    timeSelect.addEventListener('focus', function () {
        this.classList.add('scrollable');
        this.setAttribute('size', 6);  // Show 6 options at a time (adjust as needed)
    });

    // On blur (when user clicks away), revert to normal dropdown
    timeSelect.addEventListener('blur', function () {
        this.classList.remove('scrollable');
        this.removeAttribute('size');  // Back to dropdown
    });







}

document.addEventListener("DOMContentLoaded", initPatientAppointments);
