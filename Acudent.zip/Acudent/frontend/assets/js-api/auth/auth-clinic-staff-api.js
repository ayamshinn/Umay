document.addEventListener("DOMContentLoaded", () => {
    const adminLoginBtn = document.querySelector("#adminlogin");

    if (!adminLoginBtn) return;

    adminLoginBtn.addEventListener("click", async (e) => {
        e.preventDefault();

        const username = document.querySelector("#admin-user").value.trim();
        const password = document.querySelector("#admin-pass").value.trim();
        const errorMsg = document.querySelector(".error-msg");

        errorMsg.textContent = ""; // clear previous

        if (!username || !password) {
            errorMsg.textContent = "Username and password are required.";
            return;
        }

        try {
            const response = await fetch("/backend/api/auth/clinic-staff-login.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username, password })
            });

            const result = await response.json();

            if (!result.success) {
                errorMsg.textContent = result.message;
                return;
            }

            window.location.href = result.redirect;

        } catch (error) {
            console.error(error);
            errorMsg.textContent = "Login failed. Server unreachable.";
        }
    });
});
