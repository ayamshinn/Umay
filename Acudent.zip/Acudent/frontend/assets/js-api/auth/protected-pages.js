// protected-pages.js (updated)
document.addEventListener("DOMContentLoaded", () => {
    const token = localStorage.getItem('authToken');
    if (!token) {
        window.location.href = '/Acudent/frontend/views/user-interface/index.php';
    }

    // Logout function
    window.logout = async function() {
        const token = localStorage.getItem('authToken');
        console.log('Starting logout with token:', token);
        try {
            const response = await fetch('/Acudent/backend/logout.php', {
                method: 'POST',
                headers: token ? { 'Authorization': `Bearer ${token}` } : {}
            });
            console.log('Response status:', response.status);
            const responseText = await response.text();  // Get raw text first
            console.log('Raw response text:', responseText);  // DEBUG: Check for extra output
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const result = JSON.parse(responseText);  // Parse manually to catch issues
            console.log('Logout result:', result);
            if (result.success) {   
                localStorage.removeItem('authToken');
                window.location.href = '/Acudent/frontend/views/user-interface/index.php';
            } else {
                alert('Logout failed: ' + (result.message || 'Unknown error'));
            }
        } catch (err) {
            console.error('Logout error details:', err);
            alert('Logout error occurred. Redirecting anyway.');
            localStorage.removeItem('authToken');
            window.location.href = '/Acudent/frontend/views/user-interface/index.php';
        }
    };
});